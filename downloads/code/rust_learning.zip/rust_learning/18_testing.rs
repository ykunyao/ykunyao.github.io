// =============================================================================
// Rust 学习示例 18: 测试 (Testing)
// =============================================================================
// Rust 内置了对测试的支持
// 本文件将详细介绍单元测试、集成测试和测试框架

// ============================================================================
// 1. 基础测试
// ============================================================================

// 使用 #[test] 属性标记测试函数
#[test]
fn basic_test() {
    assert!(true);  // 断言为真
    assert_eq!(1 + 1, 2);  // 断言相等
    assert_ne!(1 + 1, 3);  // 断言不相等
}

// ============================================================================
// 2. assert! 系列宏
// ============================================================================

fn assert_macros() {
    println!("================== 断言宏 ==================");

    // assert! - 断言条件为真
    let condition = true;
    assert!(condition, "条件应该为真");

    // assert_eq! - 断言相等
    assert_eq!(2 + 2, 4);
    assert_eq!("hello", "hello");

    // assert_ne! - 断言不相等
    assert_ne!(2 + 2, 5);
    assert_ne!("hello", "world");

    // 带自定义消息的断言
    let x = 5;
    assert!(x > 0, "x 应该大于 0，实际值: {}", x);

    println!("所有断言通过!");
}

// ============================================================================
// 3. 测试函数组织
// ============================================================================

// 测试辅助函数（不是测试）
fn add(a: i32, b: i32) -> i32 {
    a + b
}

// 测试模块
#[cfg(test)]
mod tests {
    // 导入父模块的项
    use super::*;

    #[test]
    fn test_add_basic() {
        assert_eq!(add(2, 2), 4);
    }

    #[test]
    fn test_add_negative() {
        assert_eq!(add(-1, -1), -2);
    }

    #[test]
    fn test_add_zero() {
        assert_eq!(add(0, 0), 0);
    }

    // 测试私有函数（在同一模块内可以访问）
    fn helper() {
        println!("辅助函数");
    }
}

// ============================================================================
// 4. 单元测试
// ============================================================================

struct Calculator {
    value: i32,
}

impl Calculator {
    fn new(value: i32) -> Self {
        Calculator { value }
    }

    fn add(&mut self, n: i32) {
        self.value += n;
    }

    fn subtract(&mut self, n: i32) {
        self.value -= n;
    }

    fn multiply(&mut self, n: i32) {
        self.value *= n;
    }

    fn divide(&mut self, n: i32) -> Result<i32, &'static str> {
        if n == 0 {
            Err("除数不能为零")
        } else {
            self.value /= n;
            Ok(self.value)
        }
    }

    fn get_value(&self) -> i32 {
        self.value
    }

    // 私有方法
    fn validate(&self) -> bool {
        self.value >= 0
    }
}

#[cfg(test)]
mod calculator_tests {
    use super::*;

    #[test]
    fn test_new() {
        let calc = Calculator::new(10);
        assert_eq!(calc.get_value(), 10);
    }

    #[test]
    fn test_add() {
        let mut calc = Calculator::new(10);
        calc.add(5);
        assert_eq!(calc.get_value(), 15);
    }

    #[test]
    fn test_subtract() {
        let mut calc = Calculator::new(10);
        calc.subtract(3);
        assert_eq!(calc.get_value(), 7);
    }

    #[test]
    fn test_multiply() {
        let mut calc = Calculator::new(10);
        calc.multiply(2);
        assert_eq!(calc.get_value(), 20);
    }

    #[test]
    fn test_divide_success() {
        let mut calc = Calculator::new(10);
        let result = calc.divide(2);
        assert!(result.is_ok());
        assert_eq!(result.unwrap(), 5);
    }

    #[test]
    #[should_panic(expected = "除数不能为零")]
    fn test_divide_by_zero() {
        let mut calc = Calculator::new(10);
        calc.divide(0).unwrap();
    }

    #[test]
    fn test_divide_error_handling() {
        let mut calc = Calculator::new(10);
        let result = calc.divide(0);
        assert!(result.is_err());
        assert_eq!(result.unwrap_err(), "除数不能为零");
    }

    // 测试私有方法（在同一模块内）
    #[test]
    fn test_validate() {
        let calc = Calculator::new(10);
        assert!(calc.validate());

        let calc = Calculator::new(-5);
        assert!(!calc.validate());
    }
}

// ============================================================================
// 5. 集成测试
// ============================================================================
// 集成测试位于 tests/ 目录下
// 以下示例展示集成测试的编写方式

// 注意：这是示例代码，实际集成测试需要放在 tests/ 目录
// 创建 tests/integration_test.rs 并写入以下内容：
/*
#[test]
fn it_works() {
    assert_eq!(2 + 2, 4);
}
*/

// ============================================================================
// 6. 文档测试
// ============================================================================

/// 将两个数字相加
///
/// # Examples
///
/// ```
/// # use my_crate::add;
/// assert_eq!(add(2, 2), 4);
/// ```
///
/// # Panics
///
/// 如果参数为负数会 panic
///
/// ```
/// # use my_crate::add;
/// # add(-1, 1);
/// ```
pub fn add(a: i32, b: i32) -> i32 {
    if a < 0 || b < 0 {
        panic!("参数不能为负数");
    }
    a + b
}

// ============================================================================
// 7. 性能测试
// ============================================================================

// Rust 标准库不直接支持性能测试，但可以使用 criterion crate
// 以下是简单的性能测量示例

fn benchmark_demo() {
    println!("\n================== 性能测量 ==================");

    use std::time::{Duration, Instant};

    let start = Instant::now();
    // 执行操作
    let result: i32 = (1..=1000).sum();
    let duration = start.elapsed();

    println!("计算结果: {}", result);
    println!("耗时: {:?}", duration);
    println!("毫秒: {}", duration.as_millis());
}

// ============================================================================
// 8. 测试标记
// ============================================================================

// #[test] - 普通测试
// #[test] #[should_panic] - 预期 panic
// #[test] #[ignore] - 忽略测试
// #[bench] - 性能测试（需要 bench feature）

#[cfg(test)]
mod marks_tests {
    // 忽略测试
    #[test]
    #[ignore]
    fn ignored_test() {
        panic!("这个测试被忽略了");
    }

    // 预期 panic
    #[test]
    #[should_panic]
    fn should_panic_test() {
        panic!("这个 panic 是预期的");
    }

    // 预期特定 panic 消息
    #[test]
    #[should_panic(expected = "除数")]
    fn should_panic_with_message() {
        panic!("除数不能为零");
    }
}

// ============================================================================
// 9. 测试私有项
// ============================================================================

mod private_test_demo {
    fn helper_function(x: i32) -> i32 {
        x * 2
    }

    // 测试私有函数（在同一模块内）
    #[cfg(test)]
    mod tests {
        use super::*;

        #[test]
        fn test_helper() {
            assert_eq!(helper_function(5), 10);
        }
    }
}

// ============================================================================
// 10. 测试返回 Result
// ============================================================================

fn result_based_tests() {
    println!("\n================== Result 测试 ==================");

    // 可以返回 Result<(), E> 的测试
    // 这样可以使用 ? 操作符

    fn divide(a: i32, b: i32) -> Result<i32, &'static str> {
        if b == 0 {
            Err("division by zero")
        } else {
            Ok(a / b)
        }
    }

    // 手动测试
    match divide(10, 2) {
        Ok(result) => assert_eq!(result, 5),
        Err(e) => panic!("测试失败: {}", e),
    }

    match divide(10, 0) {
        Ok(_) => panic!("应该返回错误"),
        Err(_) => println!("正确处理了除零错误"),
    }
}

// ============================================================================
// 11. 测试夹具 (Test Fixtures)
// ============================================================================

// 使用 setup/teardown 模式
#[cfg(test)]
mod fixture_tests {
    struct TestContext {
        data: Vec<i32>,
    }

    impl TestContext {
        fn new() -> Self {
            TestContext { data: vec![1, 2, 3] }
        }
    }

    // 简单的夹具测试
    fn setup() -> TestContext {
        TestContext::new()
    }

    fn teardown(_ctx: TestContext) {
        // 清理资源
    }

    #[test]
    fn test_with_fixture() {
        let ctx = setup();
        assert_eq!(ctx.data.len(), 3);
        teardown(ctx);
    }
}

// ============================================================================
// 12. 模拟对象 (Mocking)
// ============================================================================

// 简单的模拟实现
#[cfg(test)]
mod mock_tests {
    trait Database {
        fn query(&self, sql: &str) -> Vec<String>;
        fn execute(&mut self, sql: &str) -> Result<(), &'static str>;
    }

    struct MockDatabase {
        queries: Vec<String>,
        should_fail: bool,
    }

    impl MockDatabase {
        fn new(should_fail: bool) -> Self {
            MockDatabase {
                queries: Vec::new(),
                should_fail,
            }
        }
    }

    impl Database for MockDatabase {
        fn query(&self, sql: &str) -> Vec<String> {
            vec![format!("result: {}", sql)]
        }

        fn execute(&mut self, sql: &str) -> Result<(), &'static str> {
            self.queries.push(sql.to_string());
            if self.should_fail {
                Err("mock error")
            } else {
                Ok(())
            }
        }
    }

    #[test]
    fn test_mock_database() {
        let mock = MockDatabase::new(false);
        let result = mock.query("SELECT * FROM users");
        assert_eq!(result.len(), 1);
    }

    #[test]
    fn test_mock_failure() {
        let mut mock = MockDatabase::new(true);
        let result = mock.execute("UPDATE users");
        assert!(result.is_err());
    }
}

// ============================================================================
// 13. 属性测试 (Property-based Testing)
// ============================================================================

// 使用 proptest crate 可以进行属性测试
// 以下是概念示例

fn property_test_concepts() {
    println!("\n================== 属性测试概念 ==================");

    // 交换律: a + b == b + a
    let (a, b) = (5, 3);
    assert_eq!(a + b, b + a);

    // 结合律: (a + b) + c == a + (b + c)
    let (a, b, c) = (1, 2, 3);
    assert_eq!((a + b) + c, a + (b + c));

    // 幂等性: max(a, a) == a
    let a = 42;
    assert_eq!(a.max(a), a);

    // 边界测试
    assert_eq!(0 + 0, 0);
    assert_eq!(i32::MAX, i32::MAX);
    assert_eq!(i32::MIN, i32::MIN);
}

// ============================================================================
// 14. 测试覆盖率
// ============================================================================

fn coverage_notes() {
    println!("\n================== 测试覆盖率 ==================");
    println!("使用 cargo tarpaulin 进行测试覆盖率分析:");
    println!("$ cargo install cargo-tarpaulin");
    println!("$ cargo tarpaulin --output-dir target/tarpaulin");
    println!("生成的报告会显示哪些代码被测试覆盖");
}

// ============================================================================
// 15. 测试驱动开发 (TDD) 示例
// ============================================================================

// TDD 循环：Red -> Green -> Refactor

// 第一步：写一个会失败的测试
#[cfg(test)]
mod tdd_tests {
    // 简单的栈实现
    #[derive(Debug, PartialEq)]
    pub enum StackError {
        Empty,
        Overflow,
    }

    #[derive(Debug)]
    pub struct Stack<T> {
        data: Vec<T>,
        capacity: usize,
    }

    impl<T> Stack<T> {
        pub fn new(capacity: usize) -> Self {
            Stack {
                data: Vec::new(),
                capacity,
            }
        }

        pub fn push(&mut self, value: T) -> Result<(), StackError> {
            if self.data.len() >= self.capacity {
                Err(StackError::Overflow)
            } else {
                self.data.push(value);
                Ok(())
            }
        }

        pub fn pop(&mut self) -> Result<T, StackError> {
            self.data.pop().ok_or(StackError::Empty)
        }

        pub fn is_empty(&self) -> bool {
            self.data.is_empty()
        }

        pub fn len(&self) -> usize {
            self.data.len()
        }
    }

    // ===== 测试开始 =====

    #[test]
    fn test_new_stack() {
        let stack: Stack<i32> = Stack::new(10);
        assert!(stack.is_empty());
        assert_eq!(stack.len(), 0);
    }

    #[test]
    fn test_push() {
        let mut stack = Stack::new(10);
        stack.push(1).unwrap();
        assert!(!stack.is_empty());
        assert_eq!(stack.len(), 1);
    }

    #[test]
    fn test_pop() {
        let mut stack = Stack::new(10);
        stack.push(1).unwrap();
        stack.push(2).unwrap();
        assert_eq!(stack.pop().unwrap(), 2);
        assert_eq!(stack.pop().unwrap(), 1);
    }

    #[test]
    fn test_pop_empty() {
        let mut stack: Stack<i32> = Stack::new(10);
        assert_eq!(stack.pop().unwrap_err(), StackError::Empty);
    }

    #[test]
    fn test_overflow() {
        let mut stack = Stack::new(2);
        stack.push(1).unwrap();
        stack.push(2).unwrap();
        assert_eq!(stack.push(3).unwrap_err(), StackError::Overflow);
    }

    #[test]
    fn test_generic_stack() {
        let mut stack: Stack<String> = Stack::new(5);
        stack.push(String::from("hello")).unwrap();
        stack.push(String::from("world")).unwrap();
        assert_eq!(stack.pop().unwrap(), "world");
        assert_eq!(stack.pop().unwrap(), "hello");
    }
}

// ============================================================================
// 主函数
// ============================================================================

fn main() {
    assert_macros();
    benchmark_demo();
    result_based_tests();
    property_test_concepts();
    coverage_notes();

    println!("\n================== 测试总结 ==================");
    println!();
    println!("【测试类型】");
    println!("- 单元测试: 测试单个函数/结构体");
    println!("- 集成测试: 测试多个组件交互");
    println!("- 文档测试: 测试文档中的示例");
    println!();
    println!("【断言宏】");
    println!("- assert!(condition) - 条件为真");
    println!("- assert_eq!(a, b) - 相等");
    println!("- assert_ne!(a, b) - 不等");
    println!("- #[should_panic] - 预期 panic");
    println!();
    println!("【运行测试】");
    println!("- cargo test - 运行所有测试");
    println!("- cargo test <name> - 运行指定测试");
    println!("- cargo test -- --ignored - 运行忽略的测试");
    println!();
    println!("【最佳实践】");
    println!("- 测试边界条件");
    println!("- 测试错误处理");
    println!("- 保持测试独立性");
    println!("- 使用描述性的测试名");
    println!("- 遵循 TDD 流程");
}

// ============================================================================
// 测试模块入口
// ============================================================================

#[cfg(test)]
mod integration_tests {
    // 集成测试放在 tests/ 目录
    // 只能通过 extern crate 访问库
    #[test]
    fn example_integration_test() {
        assert_eq!(2 + 2, 4);
    }
}

// =============================================================================
// Rust 学习示例 12: 生命周期 (Lifetimes)
// =============================================================================
// 生命周期是 Rust 用来确保引用始终有效的机制
// 本文件将详细介绍生命周期的概念和使用

// ============================================================================
// 1. 生命周期基础概念
// ============================================================================

fn lifetime_basics() {
    println!("================== 生命周期基础 ==================");

    // 每个引用都有一个生命周期
    // 生命周期表示引用有效的作用域

    let r;                      // 声明一个引用
    {
        let x = 5;
        r = &x;                 // r 引用 x
        println!("r: {}", r);  // 有效，因为 x 在作用域内
    }
    // println!("r: {}", r);   // 错误！x 已经离开作用域，r 成为悬垂引用

    // ============================================================================
    // 2. 生命周期注解
    // ============================================================================
    // 生命周期注解描述了引用的生命周期关系
    // 它们不会改变引用的存活时间，只是建立约束

    // 单参数生命周期
    fn longest<'a>(x: &'a str, y: &'a str) -> &'a str {
        if x.len() > y.len() {
            x
        } else {
            y
        }
    }

    // 测试
    let string1 = String::from("long string is long");
    let result;
    {
        let string2 = String::from("xyz");
        result = longest(string1.as_str(), string2.as_str());
        println!("最长字符串: {}", result);
    }
    // println!("最长字符串: {}", result);  // 错误！result 可能在 string2 之后无效

    // ============================================================================
    // 3. 结构体中的生命周期
    // ============================================================================

    struct ImportantExcerpt<'a> {
        part: &'a str,  // 生命周期必须标注
    }

    let novel = String::from("Call me Ishmael. Some years ago...");
    let first_sentence = novel.split('.').next().unwrap();

    let excerpt = ImportantExcerpt {
        part: first_sentence,
    };

    println!("引用: {}", excerpt.part);
}

// ============================================================================
// 2. 生命周期省略规则
// ============================================================================
// Rust 编译器会自动推断某些情况下的生命周期
// 这些规则叫做"生命周期省略规则"

// 推断规则：
// 1. 每个引用参数都有自己的生命周期
// 2. 如果只有一个输入生命周期，自动赋予输出生命周期
// 3. 如果有 self，self 的生命周期被赋予所有输出生命周期

fn lifetime_elision() {
    println!("\n================== 生命周期省略 ==================");

    // 这些函数实际上相同
    fn first_word(s: &str) -> &str {  // 省略后
        // 相当于: fn first_word<'a>(s: &'a str) -> &'a str
        ""
    }

    fn first_word_full<'a>(s: &'a str) -> &'a str {  // 完整写法
        s
    }

    // 需要显式标注的情况
    // 两个输入生命周期，返回引用
    // fn longest<'a>(x: &'a str, y: &'a str) -> &'a str
}

// ============================================================================
// 3. 静态生命周期
// ============================================================================

fn static_lifetime() {
    println!("\n================== 静态生命周期 ==================");

    // 'static 生命周期表示程序整个运行期间都有效
    // 字符串字面量自动拥有 'static 生命周期

    let s: &'static str = "我有静态生命周期";
    println!("静态字符串: {}", s);

    // String 有数据本身，但 &str 可能是静态的
    let s2 = "这个也是静态的";  // 编译时常量
    println!("{}", s2);

    // 全局变量也是 'static
    static COUNTER: i32 = 0;
    println!("静态变量: {}", COUNTER);
}

// ============================================================================
// 4. 生命周期与函数
// ============================================================================

fn lifetime_functions() {
    println!("\n================== 生命周期与函数 ==================");

    // 单参数生命周期（可省略）
    fn get_string(s: &str) -> &str {
        s
    }

    // 两个参数，不同生命周期
    fn first_or_last<'a>(text: &'a str, flag: bool) -> &'a str {
        if flag {
            &text[0..1]
        } else {
            &text[text.len() - 1..]
        }
    }

    let text = "hello";
    println!("first: {}", first_or_last(text, true));

    // 返回输入引用的生命周期
    fn get_first_word<'a>(s: &'a str) -> &'a str {
        s.split(' ').next().unwrap_or("")
    }

    println!("第一个单词: {}", get_first_word("hello world"));

    // 无效情况示例
    // fn dangle() -> &String {  // 错误！需要生命周期标注
    //     let s = String::from("hello");
    //     &s  // 返回对局部变量的引用
    // }

    // 正确版本：返回所有权
    fn dangle_fixed() -> String {
        String::from("hello")
    }
}

// ============================================================================
// 5. 生命周期与结构体
// ============================================================================

struct Owner<'a> {
    name: &'a str,  // 引用需要生命周期
}

struct Calculator<'a> {
    values: &'a [i32],  // 切片引用
}

impl<'a> Calculator<'a> {
    fn sum(&self) -> i32 {
        self.values.iter().sum()
    }

    fn mean(&self) -> f64 {
        if self.values.is_empty() {
            0.0
        } else {
            self.sum() as f64 / self.values.len() as f64
        }
    }
}

fn lifetime_structs() {
    println!("\n================== 生命周期与结构体 ==================");

    let name = String::from("Alice");
    let owner = Owner { name: &name };
    println!("所有者: {}", owner.name);

    let numbers = vec![1, 2, 3, 4, 5];
    let calc = Calculator { values: &numbers };
    println!("和: {}", calc.sum());
    println!("平均值: {:.2}", calc.mean());
}

// ============================================================================
// 6. 多个生命周期
// ============================================================================

fn multiple_lifetimes() {
    println!("\n================== 多个生命周期 ==================");

    // 多个生命周期参数
    fn mix<'a, 'b>(s1: &'a str, s2: &'b str) -> String {
        format!("{} and {}", s1, s2)
    }

    // 返回第一个参数的生命周期
    fn first_word<'a>(s1: &'a str, _s2: &str) -> &'a str {
        s1
    }

    let s1 = String::from("hello");
    let s2 = String::from("world");

    println!("混合: {}", mix(&s1, &s2));
    println!("第一个单词: {}", first_word(&s1, &s2));

    // 结构体多个生命周期
    struct TwoRefs<'a, 'b> {
        first: &'a str,
        second: &'b str,
    }

    let two_refs = TwoRefs {
        first: &s1,
        second: &s2,
    };
    println!("两个引用: {}, {}", two_refs.first, two_refs.second);
}

// ============================================================================
// 7. 生命周期约束
// ============================================================================

fn lifetime_bounds() {
    println!("\n================== 生命周期约束 ==================");

    // T: 'a 表示 T 必须至少活过 'a
    use std::fmt::Display;

    fn longest_with_announcement<'a, T>(
        x: &'a str,
        y: &'a str,
        ann: T,
    ) -> &'a str
    where
        T: Display,
    {
        println!("公告: {}", ann);
        if x.len() > y.len() { x } else { y }
    }

    let result = longest_with_announcement(
        "hello",
        "world!",
        "比较结果",
    );
    println!("{}", result);
}

// ============================================================================
// 8. 生命周期与方法
// ============================================================================

struct ImportantExcerpt2<'a> {
    part: &'a str,
}

impl<'a> ImportantExcerpt2<'a> {
    // 方法返回值的生命周期与 self 相同
    fn level(&self) -> i32 {
        3
    }

    // 返回值关联到 self.part
    fn announce_and_return(&self, announcement: &str) -> &str {
        println!("公告: {}", announcement);
        self.part
    }
}

fn lifetime_methods() {
    println!("\n================== 生命周期与方法 ==================");

    let novel = String::from("Call me Ishmael. Some years ago...");
    let first = novel.split('.').next().unwrap();
    let excerpt = ImportantExcerpt2 { part: first };

    println!("等级: {}", excerpt.level());
    println!("返回引用: {}", excerpt.announce_and_return("test"));
}

// ============================================================================
// 9. 生命周期与 trait
// ============================================================================

use std::fmt::Debug;

#[derive(Debug)]
struct Ref<'a, T: Debug> {
    part: &'a str,
    value: &'a T,
}

impl<'a, T: Debug> Ref<'a, T> {
    fn print(&self) {
        println!("{:?}", self.value);
    }
}

fn lifetime_with_traits() {
    println!("\n================== 生命周期与 Trait ==================");

    let value = 42;
    let r = Ref {
        part: "数字",
        value: &value,
    };

    r.print();
    println!("{:?}", r);
}

// ============================================================================
// 10. 特殊生命周期规则
// ============================================================================

fn special_lifetime_rules() {
    println!("\n================== 特殊生命周期规则 ==================");

    // 1. &'static T 总是 &'static str
    let s: &'static str = "静态字符串";

    // 2. 字符串切片引用
    let s = String::from("hello world");
    let slice: &str = &s;  // slice 的生命周期与 s 相同

    // 3. 闭包捕获的引用
    let x = 5;
    let equal_to_x = |y| y == x;  // 闭包捕获 x 的引用
    println!("{}", equal_to_x(5));

    // 4. NLL (Non-Lexical Lifetimes)
    let mut s = String::from("hello");

    let r1 = &s;         // r1 生命周期开始
    let r2 = &s;         // r2 生命周期开始
    println!("{} and {}", r1, r2);
    // r1 和 r2 在这里最后一次使用

    let r3 = &mut s;     // r3 可以使用，因为 r1, r2 已不再使用
    r3.push_str(", world");
    println!("{}", r3);
}

// ============================================================================
// 11. 常见错误与修复
// ============================================================================

fn common_errors() {
    println!("\n================== 常见错误与修复 ==================");

    // 错误1：返回局部变量的引用
    // 修复：返回所有权
    fn bad_function() -> &String {
        // let s = String::from("hello");
        // &s  // 错误！
        String::from("hello")  // 正确：返回所有权
    }

    // 错误2：引用的生命周期不明确
    // 修复：显式标注生命周期
    struct Parser<'a> {
        input: &'a str,
    }

    impl<'a> Parser<'a> {
        fn parse(&self) -> Vec<&'a str> {
            self.input.split_whitespace().collect()
        }
    }

    let input = String::from("hello world rust");
    let parser = Parser { input: &input };
    println!("解析结果: {:?}", parser.parse());

    // 错误3：结构体持有多个引用
    // 修复：为每个引用单独标注生命周期
    struct MultiRefs<'a, 'b> {
        first: &'a str,
        second: &'b str,
    }

    let s1 = String::from("first");
    let s2 = String::from("second");
    let multi = MultiRefs { first: &s1, second: &s2 };
    println!("{}, {}", multi.first, multi.second);
}

// ============================================================================
// 12. 生命周期转换
// ============================================================================

fn lifetime_coercion() {
    println!("\n================== 生命周期转换 ==================");

    // 生命周期可以扩大（协变）
    // &'a T -> &'static T (扩大)

    fn make_static(s: &str) -> &'static str {
        // s 的生命周期扩大到 'static
        // 但只能返回字面量，不能返回参数引用
        "static string"
    }

    println!("{}", make_static("hello"));

    // 'a -> 'b where 'b: 'a (长生命周期 -> 短生命周期)
    fn elapse<'short, 'long: 'short>(s: &'short str) -> &'long str {
        s  // 'short 扩大到 'long
    }

    let s = String::from("hello");
    let result: &str = elapse(&s);
    println!("{}", result);
}

// ============================================================================
// 主函数
// ============================================================================

fn main() {
    lifetime_basics();
    lifetime_elision();
    static_lifetime();
    lifetime_functions();
    lifetime_structs();
    multiple_lifetimes();
    lifetime_bounds();
    lifetime_methods();
    lifetime_with_traits();
    special_lifetime_rules();
    common_errors();
    lifetime_coercion();

    println!("\n================== 生命周期总结 ==================");
    println!();
    println!("【生命周期概念】");
    println!("- 生命周期描述引用的有效范围");
    println!("- 防止悬垂引用和无效访问");
    println!();
    println!("【生命周期标注】");
    println!("- 'a 声明生命周期参数");
    println!("- fn foo<'a>(x: &'a str) -> &'a str");
    println!();
    println!("【省略规则】");
    println!("- 单参数：自动推断");
    println!("- self 参数：返回值继承 self 的生命周期");
    println!();
    println!("【静态生命周期】");
    println!("- 'static 表示程序整个运行期间有效");
    println!("- 字符串字面量自动是 'static");
    println!();
    println!("【结构体中的生命周期】");
    println!("- 持有引用的结构体必须标注生命周期");
    println!("- impl 方法时也需要标注");
    println!();
    println!("【最佳实践】");
    println!("- 优先依赖生命周期省略规则");
    println!("- 需要时显式标注生命周期");
    println!("- 使用 'a, 'b 等简短名称");
    println!("- 注释说明复杂的生命周期关系");
}

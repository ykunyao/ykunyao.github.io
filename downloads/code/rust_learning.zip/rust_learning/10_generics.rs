// =============================================================================
// Rust 学习示例 10: 泛型 (Generics)
// =============================================================================
// 泛型允许你编写可重用的代码，适用于多种类型
// 本文件将详细介绍 Rust 中泛型的使用

// ============================================================================
// 1. 泛型函数
// ============================================================================

fn generic_functions() {
    println!("================== 泛型函数 ==================");

    // 泛型函数使用 <T> 声明类型参数
    fn largest<T: PartialOrd>(list: &[T]) -> &T {
        // T 必须实现 PartialOrd 才能比较
        let mut largest = &list[0];

        for item in list.iter() {
            if item > largest {
                largest = item;
            }
        }

        largest
    }

    let numbers = vec![34, 50, 25, 100, 65];
    let chars = vec!['y', 'm', 'a', 'q'];

    println!("最大整数: {}", largest(&numbers));
    println!("最大字符: {}", largest(&chars));

    // ============================================================================
    // 2. 泛型结构体
    // ============================================================================

    // Point 结构体，两个字段都是相同类型
    struct Point<T> {
        x: T,
        y: T,
    }

    let integer_point = Point { x: 5, y: 10 };
    let float_point = Point { x: 1.0, y: 4.0 };

    println!("整数点: ({}, {})", integer_point.x, integer_point.y);
    println!("浮点数点: ({}, {})", float_point.x, float_point.y);

    // 不同类型的 Point
    struct PointDiff<T, U> {
        x: T,
        y: U,
    }

    let mixed_point = PointDiff { x: 5, y: 4.0 };
    println!("混合点: ({}, {})", mixed_point.x, mixed_point.y);

    // ============================================================================
    // 3. 泛型枚举
    // ============================================================================

    // Option<T> 就是泛型枚举
    let some_number: Option<i32> = Some(5);
    let some_string: Option<&str> = Some("hello");
    let absent_number: Option<i32> = None;

    println!("{:?}, {:?}, {:?}", some_number, some_string, absent_number);

    // Result<T, E> 也是泛型枚举
    let ok: Result<i32, &str> = Ok(42);
    let err: Result<i32, &str> = Err("出错了");
    println!("{:?}, {:?}", ok, err);
}

// ============================================================================
// 2. 泛型方法
// ============================================================================

struct Pair<T> {
    x: T,
    y: T,
}

impl<T> Pair<T> {
    fn new(x: T, y: T) -> Self {
        Pair { x, y }
    }
}

impl<T: PartialOrd + Display> Pair<T> {
    fn cmp_display(&self) {
        if self.x >= self.y {
            println!("最大的值是: {}", self.x);
        } else {
            println!("最大的值是: {}", self.y);
        }
    }
}

// 为特定类型实现方法
impl Pair<i32> {
    fn print_coordinates(&self) {
        println!("坐标: ({}, {})", self.x, self.y);
    }
}

use std::fmt::Display;

fn generic_methods() {
    println!("\n================== 泛型方法 ==================");

    let pair = Pair::new(5, 10);
    pair.cmp_display();

    let pair_int = Pair::new(3, 7);
    pair_int.print_coordinates();

    let pair_float = Pair::new(2.5, 4.8);
    pair_float.cmp_display();
}

// ============================================================================
// 3. Trait Bound（特征约束）
// ============================================================================

fn trait_bounds() {
    println!("\n================== Trait Bound ==================");

    // 单一 trait bound
    fn print_debug<T: std::fmt::Debug>(value: T) {
        println!("{:?}", value);
    }

    print_debug(42);
    print_debug("hello");

    // 多个 trait bound（使用 +）
    fn print_display_debug<T: Display + std::fmt::Debug>(value: T) {
        println!("Display: {}", value);
        println!("Debug: {:?}", value);
    }

    print_display_debug(42);
    print_display_debug("hello");

    // where 子句（更清晰）
    fn print_if_positive<T>(value: T)
    where
        T: PartialOrd + std::fmt::Display,
    {
        if value >= T::zero() {
            println!("{}", value);
        }
    }

    // 注意：需要实现 Zero trait，这里简化处理
    // print_if_positive(5);
}

// ============================================================================
// 4. 默认泛型类型
// ============================================================================

struct PointDefault<T = i32> {
    x: T,
    y: T,
}

// 可以指定默认类型
let int_point = PointDefault { x: 5, y: 10 };
let float_point: PointDefault<f64> = PointDefault { x: 1.0, y: 4.0 };

// ============================================================================
// 5. 关联类型
// ============================================================================

// 关联类型：在 trait 中声明类型占位符
trait Container {
    type Item;  // 关联类型
    fn get(&self, index: usize) -> Option<&Self::Item>;
    fn len(&self) -> usize;
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

struct SimpleVec<T> {
    data: Vec<T>,
}

impl<T> Container for SimpleVec<T> {
    type Item = T;

    fn get(&self, index: usize) -> Option<&T> {
        self.data.get(index)
    }

    fn len(&self) -> usize {
        self.data.len()
    }
}

fn associated_types() {
    println!("\n================== 关联类型 ==================");

    let vec = SimpleVec {
        data: vec![1, 2, 3, 4, 5],
    };

    println!("容器长度: {}", vec.len());
    println!("容器是否为空: {}", vec.is_empty());
    println!("索引 2 的值: {:?}", vec.get(2));
}

// ============================================================================
// 6. 泛型与生命周期
// ============================================================================

// 泛型与生命周期的组合
fn longest_with_an_annotation<'a, T>(x: &'a str, y: &'a str, _func: T) -> &'a str
where
    T: Fn(&str) -> &str,
{
    if x.len() > y.len() {
        x
    } else {
        y
    }
}

// ============================================================================
// 7. 泛型性能
// ============================================================================

// Rust 的泛型是单态化（Monomorphization）的
// 编译器会在编译时为每种具体类型生成专门的代码
// 这意味着泛型没有运行时开销

// 这两个调用会生成两个版本的函数
fn performance_example() {
    println!("\n================== 泛型性能 ==================");

    let result1 = largest(&vec![1, 5, 3, 2, 4]);
    let result2 = largest(&vec![1.0, 5.0, 3.0, 2.0, 4.0]);

    println!("最大整数: {}", result1);
    println!("最大浮点数: {}", result2);

    // 编译时会为 i32 和 f64 分别生成代码
    // 这叫做"单态化"，零成本抽象
}

// ============================================================================
// 8. 泛型约束进阶
// ============================================================================

// 自动实现 trait
fn auto_trait_impls() {
    println!("\n================== 自动 trait 实现 ==================");

    // 所有泛型类型自动实现这些 trait：
    // - Debug（如果所有字段都实现 Debug）
    // - Clone（如果所有字段都实现 Clone）
    // - Copy（如果所有字段都实现 Copy）
    // - Default（如果所有字段都实现 Default）

    #[derive(Debug, Clone, Copy, Default)]
    struct Point3D<T = i32> {
        x: T,
        y: T,
        z: T,
    }

    let p1 = Point3D { x: 1, y: 2, z: 3 };
    let p2 = p1;  // Copy
    let p3 = p1.clone();  // Clone
    println!("Debug: {:?}", p1);
    println!("p2: {:?}, p3: {:?}", p2, p3);

    let default_point: Point3D<i32> = Point3D::default();
    println!("默认点: {:?}", default_point);

    let default_float: Point3D<f64> = Point3D::default();
    println!("默认浮点: {:?}", default_float);
}

// ============================================================================
// 9. 泛型参数命名
// ============================================================================

// Rust 惯例：
// - T: 单个类型
// - U, V: 多个类型
// - E: 错误类型
// - K, V: 键值对
// - I: 迭代器
// - R: 返回类型
// - F: 函数/闭包

// 零值优化
struct Wrapper<T> {
    value: T,
}

impl<T> Wrapper<T> {
    fn new(value: T) -> Self {
        Wrapper { value }
    }

    fn unwrap(self) -> T {
        self.value
    }
}

// ============================================================================
// 10. 泛型在标准库中的应用
// ============================================================================

fn std_generic_types() {
    println!("\n================== 标准库泛型应用 ==================");

    // Vec<T>
    let vec: Vec<i32> = vec![1, 2, 3, 4, 5];
    println!("Vec<i32>: {:?}", vec);

    // HashMap<K, V>
    use std::collections::HashMap;
    let mut map: HashMap<&str, i32> = HashMap::new();
    map.insert("apple", 3);
    map.insert("banana", 5);
    println!("HashMap: {:?}", map);

    // Box<T>
    let boxed: Box<i32> = Box::new(42);
    println!("Box<i32>: {}", boxed);

    // Arc<T>
    use std::sync::Arc;
    let arc: Arc<i32> = Arc::new(42);
    println!("Arc<i32>: {}", arc);

    // Cell<T>, RefCell<T>
    use std::cell::Cell;
    let cell: Cell<i32> = Cell::new(42);
    cell.set(100);
    println!("Cell<i32>: {}", cell.get());
}

// ============================================================================
// 11. 泛型与 trait 对象
// ============================================================================

// 泛型 vs trait 对象
fn generic_vs_trait_object() {
    println!("\n================== 泛型 vs Trait 对象 ==================");

    // 泛型方法：编译时决定具体类型
    // trait 对象方法：运行时决定具体类型

    // 泛型方式：静态分发（static dispatch）
    // fn print_static<T: std::fmt::Display>(val: &T) {
    //     println!("{}", val);
    // }

    // trait 对象方式：动态分发（dynamic dispatch）
    fn print_dynamic(val: &dyn std::fmt::Display) {
        println!("{}", val);
    }

    print_dynamic(&42);
    print_dynamic(&"hello");

    // 区别：
    // - 泛型：性能更好，但代码膨胀
    // - trait 对象：灵活，但有虚函数表开销
}

// ============================================================================
// 12. 条件实现
// ============================================================================

// 基于 trait 实现的方法
struct GenericStruct<T> {
    value: T,
}

impl<T> GenericStruct<T> {
    fn new(value: T) -> Self {
        GenericStruct { value }
    }
}

// 仅当 T 实现了 Display 时实现
impl<T: Display> GenericStruct<T> {
    fn show(&self) {
        println!("显示: {}", self.value);
    }
}

// 仅当 T 实现了 Clone 时实现
impl<T: Clone> GenericStruct<T> {
    fn clone_value(&self) -> Self {
        GenericStruct {
            value: self.value.clone(),
        }
    }
}

// 仅当 T 同时实现 Clone 和 Debug 时实现
impl<T: Clone + std::fmt::Debug> GenericStruct<T> {
    fn debug_clone(&self) {
        println!("调试克隆: {:?}", self.value);
    }
}

fn conditional_impl() {
    println!("\n================== 条件实现 ==================");

    let gs = GenericStruct::new(42);
    gs.show();
    let cloned = gs.clone_value();
    cloned.debug_clone();

    let gs2 = GenericStruct::new("hello");
    gs2.show();
}

// ============================================================================
// 主函数
// ============================================================================

fn main() {
    generic_functions();
    generic_methods();
    associated_types();
    performance_example();
    auto_trait_impls();
    std_generic_types();
    generic_vs_trait_object();
    conditional_impl();

    println!("\n================== 泛型总结 ==================");
    println!();
    println!("【泛型基础】");
    println!("- 使用 <T> 声明类型参数");
    println!("- 泛型函数、泛型结构体、泛型枚举");
    println!();
    println!("【Trait Bound】");
    println!("- T: Trait 指定类型必须实现的 trait");
    println!("- 使用 + 指定多个 trait");
    println!("- 使用 where 子句提高可读性");
    println!();
    println!("【关联类型】");
    println!("- 在 trait 中使用 type 声明类型占位符");
    println!("- impl 时提供具体类型");
    println!();
    println!("【性能】");
    println!("- 单态化：编译时生成专用代码");
    println!("- 零成本抽象，无运行时开销");
    println!();
    println!("【最佳实践】");
    println!("- 优先使用泛型而非 trait 对象（性能更好）");
    println!("- 使用条件实现为特定类型添加方法");
    println!("- 遵循惯例命名泛型参数");
}

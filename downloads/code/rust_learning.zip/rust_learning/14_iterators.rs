// =============================================================================
// Rust 学习示例 14: 迭代器 (Iterators)
// =============================================================================
// 迭代器是 Rust 中处理序列的一种强大方式
// 本文件将详细介绍迭代器的创建、使用和适配器

// ============================================================================
// 1. 迭代器基础
// ============================================================================

fn iterator_basics() {
    println!("================== 迭代器基础 ==================");

    // 迭代器是一个 trait
    // trait Iterator {
    //     type Item;  // 迭代产生的元素类型
    //     fn next(&mut self) -> Option<Self::Item>;
    // }

    // 创建迭代器
    let v = vec![1, 2, 3];

    // iter() - 产生不可变引用的迭代器
    let mut iter = v.iter();
    println!("iter():");
    while let Some(val) = iter.next() {
        print!("{} ", val);
    }
    println!();

    // iter_mut() - 产生可变引用的迭代器
    let mut v = vec![1, 2, 3];
    for val in v.iter_mut() {
        *val *= 2;
    }
    println!("iter_mut() 后: {:?}", v);

    // into_iter() - 获取所有权的迭代器
    let v = vec![1, 2, 3];
    let mut iter = v.into_iter();
    println!("into_iter():");
    while let Some(val) = iter.next() {
        print!("{} ", val);
    }
    println!();
    // println!("{:?}", v);  // 错误！v 已被移动

    // ============================================================================
    // 2. for 循环与迭代器
    // ============================================================================

    let v = vec![1, 2, 3];

    // for 循环自动调用 into_iter()
    println!("for 循环:");
    for val in v {
        print!("{} ", val);
    }
    println!();

    // 使用 iter() 在循环后保留所有权
    let v = vec![1, 2, 3];
    println!("for val in &v:");
    for val in &v {
        print!("{} ", val);
    }
    println!();
    println!("v 仍然可用: {:?}", v);

    // ============================================================================
    // 3. 迭代器方法
    // ============================================================================

    let iter = 0..10;  // Range 实现了 Iterator

    // next() - 获取下一个元素
    let mut iter = iter;
    println!("next(): {}", iter.next().unwrap());
    println!("next(): {}", iter.next().unwrap());
    println!("next(): {}", iter.next().unwrap());

    // collect() - 收集到容器
    let v: Vec<_> = (1..=5).collect();
    println!("collect: {:?}", v);

    // nth() - 获取第 n 个元素
    let iter = 10..=20;
    let third = iter.nth(2);  // 0-indexed
    println!("nth(2): {:?}", third);

    // count() - 计数
    let count = (1..=100).count();
    println!("count 1..=100: {}", count);

    // last() - 获取最后一个元素
    let last = (1..=10).last();
    println!("last: {:?}", last);

    // sum() - 求和
    let sum: i32 = (1..=100).sum();
    println!("sum 1..=100: {}", sum);

    // product() - 求积
    let product: i32 = (1..=5).product();
    println!("product 1..=5: {}", product);
}

// ============================================================================
// 2. 迭代器适配器 (Iterator Adapters)
// ============================================================================
// 迭代器适配器将迭代器转换为其他迭代器
// 它们是惰性的，只有消费者方法调用时才会执行

fn iterator_adaptors() {
    println!("\n================== 迭代器适配器 ==================");

    let numbers = vec![1, 2, 3, 4, 5];

    // map - 转换每个元素
    let doubled: Vec<_> = numbers.iter().map(|x| x * 2).collect();
    println!("map (*2): {:?}", doubled);

    // filter - 过滤元素
    let evens: Vec<_> = numbers.iter().filter(|x| *x % 2 == 0).collect();
    println!("filter (偶数): {:?}", evens);

    // filter_map - 同时过滤和转换
    let strings = vec!["1", "two", "3", "four", "5"];
    let numbers: Vec<_> = strings.iter()
        .filter_map(|s| s.parse::<i32>().ok())
        .collect();
    println!("filter_map 解析: {:?}", numbers);

    // enumerate - 添加索引
    let indexed: Vec<_> = numbers.iter().enumerate().collect();
    println!("enumerate: {:?}", indexed);

    // zip - 合并两个迭代器
    let names = vec!["a", "b", "c"];
    let zipped: Vec<_> = numbers.iter().zip(names.iter()).collect();
    println!("zip: {:?}", zipped);

    // take 和 skip
    println!("take(3): {:?}", (1..=10).take(3).collect::<Vec<_>>());
    println!("skip(3): {:?}", (1..=10).skip(3).collect::<Vec<_>>());

    // take_while 和 skip_while
    println!("take_while(<5): {:?}", (1..=10).take_while(|x| *x < 5).collect::<Vec<_>>());
    println!("skip_while(<5): {:?}", (1..=10).skip_while(|x| *x < 5).collect::<Vec<_>>());

    // peekable - 可以预览下一个元素
    let mut iter = (1..=5).peekable();
    println!("peek: {:?}", iter.peek());
    println!("peek: {:?}", iter.peek());
    println!("next: {:?}", iter.next());

    // fuse - 遇到 None 后始终返回 None
    let mut iter = (1..=3).fuse();
    while let Some(v) = iter.next() {
        print!("{} ", v);
    }
    println!(" (fuse 后)");
    println!("再次调用: {:?}", iter.next());

    // cycle - 无限循环
    let cycle: Vec<_> = (1..=3).cycle().take(10).collect();
    println!("cycle take(10): {:?}", cycle);

    // rev - 反转
    let reversed: Vec<_> = (1..=5).rev().collect();
    println!("rev: {:?}", reversed);

    // flatten - 展平嵌套结构
    let nested = vec![vec![1, 2], vec![3, 4], vec![5]];
    let flat: Vec<_> = nested.into_iter().flatten().collect();
    println!("flatten: {:?}", flat);

    // flat_map - map + flatten
    let words = vec!["hello", "world"];
    let chars: Vec<_> = words.iter().flat_map(|s| s.chars()).collect();
    println!("flat_map chars: {:?}", chars);

    // chain - 连接迭代器
    let chained: Vec<_> = (1..=3).chain([4, 5, 6].iter().copied()).collect();
    println!("chain: {:?}", chained);

    // inspect - 调试用
    let result: Vec<_> = (1..=5)
        .inspect(|x| println!("处理前: {}", x))
        .map(|x| x * 2)
        .inspect(|x| println!("处理后: {}", x))
        .collect();
    println!("inspect 结果: {:?}", result);
}

// ============================================================================
// 3. 消费者方法 (Consumer Methods)
// ============================================================================
// 消费者方法会消耗迭代器并产生最终结果

fn consumer_methods() {
    println!("\n================== 消费者方法 ==================");

    // collect - 收集到容器
    let v: Vec<_> = (1..=5).collect();
    println!("collect: {:?}", v);

    let set: std::collections::HashSet<_> = (1..=5).collect();
    println!("collect -> HashSet: {:?}", set);

    let map: std::collections::HashMap<_, _> = vec!["a", "b", "c"]
        .iter()
        .enumerate()
        .map(|(i, s)| (i as i32, *s))
        .collect();
    println!("collect -> HashMap: {:?}", map);

    // fold - 折叠
    let sum = (1..=10).fold(0, |acc, x| acc + x);
    println!("fold sum: {}", sum);

    let product = (1..=5).fold(1, |acc, x| acc * x);
    println!("fold product: {}", product);

    let max = (1..=10).fold(i32::MIN, |acc, x| acc.max(x));
    println!("fold max: {}", max);

    // reduce - 类似 fold，但使用第一个元素作为初始值
    let result = (1..=5).reduce(|acc, x| acc + x);
    println!("reduce sum: {:?}", result);

    // sum 和 product（专用实现，更高效）
    println!("sum: {}", (1..=100).sum::<i32>());
    println!("product: {}", (1..=10).product::<i32>());

    // find - 查找第一个满足条件的元素
    let result = (1..=100).find(|x| *x > 50);
    println!("find > 50: {:?}", result);

    // position - 查找第一个满足条件的元素的索引
    let result = (1..=100).position(|x| *x == 42);
    println!("position of 42: {:?}", result);

    // any 和 all
    let numbers = vec![1, 2, 3, 4, 5];
    println!("any even: {}", numbers.iter().any(|x| *x % 2 == 0));
    println!("all > 0: {}", numbers.iter().all(|x| *x > 0));
    println!("any > 5: {}", numbers.iter().any(|x| *x > 5));

    // count
    let evens = (1..=100).filter(|x| *x % 2 == 0).count();
    println!("count even in 1..=100: {}", evens);

    // max 和 min
    println!("max: {:?}", (1..=100).max());
    println!("min: {:?}", (1..=100).min());

    // max_by 和 min_by
    let words = vec!["apple", "pie", "hello", "world"];
    println!("longest: {:?}", words.iter().max_by_key(|s| s.len()));

    // for_each - 对每个元素执行操作
    print!("for_each: ");
    (1..=5).for_each(|x| print!("{} ", x));
    println!();

    // partition - 按条件分组
    let (evens, odds): (Vec<_>, Vec<_>) = (1..=10).partition(|x| *x % 2 == 0);
    println!("partition: evens={:?}, odds={:?}", evens, odds);
}

// ============================================================================
// 4. 自定义迭代器
// ============================================================================

struct Counter {
    current: u32,
    max: u32,
}

impl Counter {
    fn new(max: u32) -> Counter {
        Counter { current: 0, max }
    }
}

impl Iterator for Counter {
    type Item = u32;

    fn next(&mut self) -> Option<Self::Item> {
        if self.current < self.max {
            self.current += 1;
            Some(self.current)
        } else {
            None
        }
    }
}

fn custom_iterator() {
    println!("\n================== 自定义迭代器 ==================");

    let counter = Counter::new(5);
    let v: Vec<_> = counter.collect();
    println!("Counter 收集: {:?}", v);

    // 使用自定义迭代器
    let counter = Counter::new(10);
    let sum: u32 = counter.sum();
    println!("Counter sum: {}", sum);

    // 链式操作
    let result: Vec<_> = Counter::new(5)
        .zip(Counter::new(5).skip(1))
        .map(|(a, b)| a * b)
        .filter(|x| x % 3 == 0)
        .collect();
    println!("Counter 链式: {:?}", result);

    // enumerate
    let counter = Counter::new(3);
    let indexed: Vec<_> = counter.enumerate().collect();
    println!("Counter enumerate: {:?}", indexed);

    // take 和 skip
    let counter = Counter::new(10);
    let result: Vec<_> = counter.skip(2).take(5).collect();
    println!("Counter skip(2).take(5): {:?}", result);
}

// ============================================================================
// 5. 迭代器与闭包
// ============================================================================

fn iterator_with_closures() {
    println!("\n================== 迭代器与闭包 ==================");

    // 使用闭包自定义行为
    let data = vec![1, 2, 3, 4, 5];

    // 自定义排序
    let mut sorted = data.clone();
    sorted.sort_by(|a, b| b.cmp(a));  // 降序
    println!("降序排序: {:?}", sorted);

    // 自定义分组
    let words = vec!["apple", "banana", "apricot", "blueberry", "cherry"];
    let grouped: std::collections::HashMap<_, Vec<_>> = words
        .iter()
        .fold(std::collections::HashMap::new(), |mut acc, word| {
            let first = word.chars().next().unwrap();
            acc.entry(first).or_insert_with(Vec::new).push(*word);
            acc
        });
    println!("按首字母分组: {:?}", grouped);

    // 复杂的链式操作
    let result = (1..=100)
        .filter(|x| x % 2 == 0)           // 偶数
        .map(|x| x * x)                    // 平方
        .filter(|x| *x < 1000)            // 小于1000
        .take(10)                         // 取前10个
        .fold(0, |acc, x| acc + x);       // 求和
    println!("复杂链式: {}", result);
}

// ============================================================================
// 6. 实现 DoubleEndedIterator
// ============================================================================

struct Fibonacci {
    current: u64,
    next: u64,
}

impl Fibonacci {
    fn new() -> Self {
        Fibonacci { current: 0, next: 1 }
    }
}

impl Default for Fibonacci {
    fn default() -> Self {
        Self::new()
    }
}

impl Iterator for Fibonacci {
    type Item = u64;

    fn next(&mut self) -> Option<Self::Item> {
        let current = self.current;
        self.current = self.next;
        self.next = current + self.next;
        Some(current)
    }
}

impl DoubleEndedIterator for Fibonacci {
    fn next_back(&mut self) -> Option<Self::Item> {
        // 反向迭代器不适用于无限序列
        None
    }
}

fn double_ended_iterator() {
    println!("\n================== 双向迭代器 ==================");

    let fib = Fibonacci::new();
    let v: Vec<_> = fib.take(10).collect();
    println!("Fibonacci: {:?}", v);

    // 反转
    let v = vec![1, 2, 3, 4, 5];
    let reversed: Vec<_> = v.iter().rev().copied().collect();
    println!("反转: {:?}", reversed);
}

// ============================================================================
// 7. 实现 ExactSizeIterator
// ============================================================================

struct FixedCounter {
    count: usize,
    current: usize,
}

impl FixedCounter {
    fn new(count: usize) -> Self {
        FixedCounter { count, current: 0 }
    }
}

impl Iterator for FixedCounter {
    type Item = usize;

    fn next(&mut self) -> Option<Self::Item> {
        if self.current < self.count {
            self.current += 1;
            Some(self.current)
        } else {
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let remaining = self.count - self.current;
        (remaining, Some(remaining))
    }
}

impl ExactSizeIterator for FixedCounter {}

fn exact_size_iterator() {
    println!("\n================== ExactSizeIterator ==================");

    let counter = FixedCounter::new(5);
    println!("ExactSizeIterator len: {}", counter.len());

    let mut counter = FixedCounter::new(5);
    counter.next();
    counter.next();
    println!("消耗2个后 len: {}", counter.len());
}

// ============================================================================
// 8. 迭代器性能
// ============================================================================

fn iterator_performance() {
    println!("\n================== 迭代器性能 ==================");

    // 迭代器是零成本抽象
    // 编译器会将迭代器链优化为单个循环

    let sum: i32 = (0..1000).map(|x| x * 2).filter(|x| x % 3 == 0).sum();
    println!("优化后的链式迭代: {}", sum);

    // 等价的 for 循环
    let mut sum = 0;
    for x in 0..1000 {
        let doubled = x * 2;
        if doubled % 3 == 0 {
            sum += doubled;
        }
    }
    println!("for 循环结果: {}", sum);
}

// ============================================================================
// 9. 实用示例
// ============================================================================

fn practical_examples() {
    println!("\n================== 实用示例 ==================");

    // 字符串处理
    let text = "hello world rust programming";
    let words: Vec<_> = text.split_whitespace().collect();
    println!("单词: {:?}", words);

    let word_lengths: Vec<_> = text.split_whitespace()
        .map(|w| w.len())
        .collect();
    println!("单词长度: {:?}", word_lengths);

    // 文件处理
    let lines = vec!["line1", "line2", "line3"];
    let numbered: Vec<_> = lines.iter()
        .enumerate()
        .map(|(i, l)| format!("{}: {}", i + 1, l))
        .collect();
    println!("编号行: {:?}", numbered);

    // 数据转换
    let data = vec![("Alice", 25), ("Bob", 30), ("Charlie", 35)];
    let names: Vec<_> = data.iter().map(|(name, _)| *name).collect();
    let ages: Vec<_> = data.iter().map(|(_, age)| *age).collect();
    println!("名字: {:?}", names);
    println!("年龄: {:?}", ages);

    // 分组和聚合
    let scores = vec![85, 92, 78, 95, 88, 72, 91];
    let (above_80, below_80): (Vec<_>, Vec<_>) = scores.iter()
        .partition(|&&s| s >= 80);
    println!(">=80: {:?}, <80: {:?}", above_80, below_80);
    let avg: f64 = above_80.iter().copied().sum::<i32>() as f64 / above_80.len() as f64;
    println!(">=80 平均分: {:.2}", avg);
}

// ============================================================================
// 主函数
// ============================================================================

fn main() {
    iterator_basics();
    iterator_adaptors();
    consumer_methods();
    custom_iterator();
    iterator_with_closures();
    double_ended_iterator();
    exact_size_iterator();
    iterator_performance();
    practical_examples();

    println!("\n================== 迭代器总结 ==================");
    println!();
    println!("【迭代器创建】");
    println!("- vec.iter() - 不可变引用");
    println!("- vec.iter_mut() - 可变引用");
    println!("- vec.into_iter() - 获取所有权");
    println!("- (start..end) - Range");
    println!();
    println!("【迭代器适配器（惰性）】");
    println!("- map, filter, filter_map");
    println!("- take, skip, take_while, skip_while");
    println!("- enumerate, zip, chain");
    println!("- flatten, flat_map, cycle");
    println!("- rev, peekable");
    println!();
    println!("【消费者方法】");
    println!("- collect - 收集到容器");
    println!("- fold, reduce - 折叠");
    println!("- sum, product, count");
    println!("- find, position, any, all");
    println!("- max, min, for_each");
    println!();
    println!("【优势】");
    println!("- 零成本抽象");
    println!("- 惰性求值，高效组合");
    println!("- 声明式代码，更易读");
}

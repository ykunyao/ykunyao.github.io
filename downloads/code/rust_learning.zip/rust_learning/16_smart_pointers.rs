// =============================================================================
// Rust 学习示例 16: 智能指针 (Smart Pointers)
// =============================================================================
// 智能指针是实现了 Deref 和 Drop trait 的数据结构
// 本文件将详细介绍 Box, Rc, RefCell, Arc, Mutex 等常用智能指针

// ============================================================================
// 1. Box<T> - 堆分配
// ============================================================================

fn box_examples() {
    println!("================== Box<T> ==================");

    // 在堆上分配数据
    let b = Box::new(5);
    println!("Box containing: {}", b);

    // 解引用 Box
    let b = Box::new(42);
    let value = *b;
    println!("解引用: {}", value);

    // Box 作为递归类型的所有权
    #[derive(Debug)]
    enum List {
        Cons(i32, Box<List>),
        Nil,
    }

    use List::{Cons, Nil};

    let list = Cons(1,
        Box::new(Cons(2,
            Box::new(Cons(3,
                Box::new(Nil))))));

    println!("递归列表: {:?}", list);

    // ============================================================================
    // 2. Box 作为递归类型
    // ============================================================================

    #[derive(Debug)]
    enum Tree<T> {
        Node {
            value: T,
            left: Option<Box<Tree<T>>>,
            right: Option<Box<Tree<T>>>,
        },
        Leaf,
    }

    let tree = Tree::Node {
        value: 1,
        left: Some(Box::new(Tree::Node {
            value: 2,
            left: Some(Box::new(Tree::Leaf)),
            right: Some(Box::new(Tree::Leaf)),
        })),
        right: Some(Box::new(Tree::Leaf)),
    };

    println!("二叉树: {:?}", tree);

    // ============================================================================
    // 3. Box 作为 trait 对象
    // ============================================================================

    trait Drawable {
        fn draw(&self);
    }

    struct Circle {
        radius: f64,
    }

    impl Drawable for Circle {
        fn draw(&self) {
            println!("画圆，半径: {}", self.radius);
        }
    }

    struct Rectangle {
        width: f64,
        height: f64,
    }

    impl Drawable for Rectangle {
        fn draw(&self) {
            println!("画矩形: {}x{}", self.width, self.height);
        }
    }

    let shapes: Vec<Box<dyn Drawable>> = vec![
        Box::new(Circle { radius: 5.0 }),
        Box::new(Rectangle { width: 10.0, height: 20.0 }),
    ];

    for shape in &shapes {
        shape.draw();
    }

    // ============================================================================
    // 4. Box 常用方法
    // ============================================================================

    let b = Box::new(5);

    // into_inner 解包
    let value = Box::new(10).into_inner();
    println!("into_inner: {}", value);

    // leak 泄漏 Box 的所有权
    let data = Box::new(String::from("hello"));
    let leaked: &'static str = Box::leak(data);
    println!("leaked: {}", leaked);
    // leaked 将在程序结束时被释放
}

// ============================================================================
// 2. Rc<T> - 引用计数
// ============================================================================
// Rc 允许多个所有权，适用于单线程场景

fn rc_examples() {
    println!("\n================== Rc<T> ==================");

    use std::rc::Rc;

    // 创建 Rc
    let rc1 = Rc::new(5);
    println!("初始引用计数: {}", Rc::strong_count(&rc1));

    // clone 增加引用计数（不会深拷贝数据）
    let rc2 = Rc::clone(&rc1);
    println!("clone 后计数: {}", Rc::strong_count(&rc1));

    let rc3 = Rc::clone(&rc1);
    println!("再次 clone: {}", Rc::strong_count(&rc1));

    // 所有 Rc 指向相同数据
    println!("rc1: {}, rc2: {}, rc3: {}", rc1, rc2, rc3);

    // ============================================================================
    // 2. Rc 与结构体
    // ============================================================================

    #[derive(Debug)]
    struct Person {
        name: String,
    }

    let alice = Rc::new(Person {
        name: String::from("Alice"),
    });

    let bob = Person {
        name: String::from("Bob"),
    };

    println!("Alice ref count: {}", Rc::strong_count(&alice));

    {
        let alice_ref = Rc::clone(&alice);
        println!("内部 ref count: {}", Rc::strong_count(&alice));
    }

    println!("内部结束后 ref count: {}", Rc::strong_count(&alice));

    // ============================================================================
    // 3. Rc 与 RefCell 组合
    // ============================================================================

    use std::cell::RefCell;

    let rc_refcell = Rc::new(RefCell::new(vec![1, 2, 3]));

    // 可变借用
    rc_refcell.borrow_mut().push(4);
    println!("borrow_mut: {:?}", rc_refcell.borrow());

    // ============================================================================
    // 4. Rc 的限制
    // ============================================================================

    // Rc 不是线程安全的
    // 需要多线程共享时使用 Arc

    let rc = Rc::new(5);
    // std::thread::spawn(move || {
    //     println!("rc in thread: {}", rc);  // 编译错误！
    // });
}

// ============================================================================
// 3. RefCell<T> - 内部可变性
// ============================================================================
// RefCell 允许在不可变引用的条件下修改数据

fn refcell_examples() {
    println!("\n================== RefCell<T> ==================");

    use std::cell::RefCell;

    let data = RefCell::new(5);

    // 不可变借用（可变数据）
    let borrowed = data.borrow();
    println!("immutable borrow: {}", borrowed);

    // 不可变借用时不能再次借用
    // let borrowed2 = data.borrow();  // panic! 借用冲突

    drop(borrowed);  // 释放借用

    // 可变借用
    *data.borrow_mut() = 10;
    println!("after mutable borrow: {:?}", data);

    // ============================================================================
    // 2. 运行时借用检查
    // ============================================================================

    let data = RefCell::new(vec![1, 2, 3]);

    // 安全的多重借用（运行时检查）
    {
        let first = data.borrow()[0];
        println!("first element: {}", first);
    }

    {
        let all = data.borrow();
        println!("all elements: {:?}", all);
    }

    // 危险的借用会在运行时 panic
    // let mutable_borrow = data.borrow_mut();
    // let immutable_borrow = data.borrow();  // panic!

    // ============================================================================
    // 3. 与 Rc 组合实现可变的共享数据
    // ============================================================================

    use std::rc::Rc;

    let shared_data = Rc::new(RefCell::new(vec![1, 2, 3]));

    // 多个所有者都可以修改数据
    let ref1 = Rc::clone(&shared_data);
    let ref2 = Rc::clone(&shared_data);

    ref1.borrow_mut().push(4);
    println!("ref1: {:?}", ref1.borrow());
    println!("ref2: {:?}", ref2.borrow());
    println!("shared: {:?}", shared_data.borrow());

    // ============================================================================
    // 4. RefCell 在结构体中的应用
    // ============================================================================

    struct Logger {
        messages: RefCell<Vec<String>>,
    }

    impl Logger {
        fn new() -> Self {
            Logger {
                messages: RefCell::new(Vec::new()),
            }
        }

        fn log(&self, msg: &str) {
            self.messages.borrow_mut().push(msg.to_string());
        }

        fn get_messages(&self) -> Vec<String> {
            self.messages.borrow().clone()
        }
    }

    let logger = Logger::new();
    logger.log("Hello");
    logger.log("World");
    println!("日志: {:?}", logger.get_messages());
}

// ============================================================================
// 4. Arc<T> - 原子引用计数
// ============================================================================
// Arc 是线程安全的 Rc

fn arc_examples() {
    println!("\n================== Arc<T> ==================");

    use std::sync::Arc;
    use std::thread;

    // 创建 Arc
    let data = Arc::new(5);

    // 在多个线程中使用
    let data_clone1 = Arc::clone(&data);
    let data_clone2 = Arc::clone(&data);

    let handle1 = thread::spawn(move || {
        println!("thread1: {}", data_clone1);
    });

    let handle2 = thread::spawn(move || {
        println!("thread2: {}", data_clone2);
    });

    handle1.join().unwrap();
    handle2.join().unwrap();

    println!("主线程: {}", data);

    // ============================================================================
    // 2. Arc 与 Mutex 组合
    // ============================================================================

    use std::sync::Mutex;

    let counter = Arc::new(Mutex::new(0));

    let handles: Vec<_> = (0..10).map(|_| {
        let counter = Arc::clone(&counter);
        thread::spawn(move || {
            let mut num = counter.lock().unwrap();
            *num += 1;
        })
    }).collect();

    for handle in handles {
        handle.join().unwrap();
    }

    println!("最终计数: {}", *counter.lock().unwrap());

    // ============================================================================
    // 3. Arc<Mutex<T>> 常用模式
    // ============================================================================

    let shared_vec = Arc::new(Mutex::new(vec![1, 2, 3]));

    let shared_vec_clone = Arc::clone(&shared_vec);
    let handle = thread::spawn(move || {
        let mut v = shared_vec_clone.lock().unwrap();
        v.push(4);
    });

    handle.join().unwrap();

    let v = shared_vec.lock().unwrap();
    println!("共享 Vec: {:?}", v);
}

// ============================================================================
// 5. Cell<T> - 简单内部可变性
// ============================================================================

fn cell_examples() {
    println!("\n================== Cell<T> ==================");

    use std::cell::Cell;

    // Cell<T> 适用于 Copy 类型
    let cell = Cell::new(5);

    // get 和 set
    println!("get: {}", cell.get());
    cell.set(10);
    println!("set 后 get: {}", cell.get());

    // update
    cell.update(|x| x * 2);
    println!("update 后: {}", cell.get());

    // ============================================================================
    // 2. Cell vs RefCell
    // ============================================================================

    // Cell<T>:
    // - 适用于 Copy 类型 (T: Copy)
    // - 通过 get/set 复制值
    // - 无运行时开销

    // RefCell<T>:
    // - 适用于非 Copy 类型
    // - 通过 borrow/borrow_mut 返回引用
    // - 有运行时借用检查开销

    let cell = Cell::new(String::from("hello"));
    // cell.set(String::from("world"));  // 错误！String 不是 Copy

    let refcell = std::cell::RefCell::new(String::from("hello"));
    refcell.borrow_mut().push_str(" world");
    println!("RefCell: {}", refcell.borrow());
}

// ============================================================================
// 6. Mutex<T> - 互斥锁
// ============================================================================

fn mutex_examples() {
    println!("\n================== Mutex<T> ==================");

    use std::sync::Mutex;

    // 创建 Mutex
    let mutex = Mutex::new(0);

    // lock 获取锁
    {
        let mut value = mutex.lock().unwrap();
        *value += 1;
        println!("加锁后: {}", *value);
    }  // lock 在这里自动释放

    // 使用 try_lock 尝试获取锁
    match mutex.try_lock() {
        Ok(mut value) => {
            *value += 1;
            println!("try_lock 成功: {}", *value);
        }
        Err(_) => {
            println!("锁被占用");
        }
    }

    // ============================================================================
    // 2. MutexGuard
    // ============================================================================

    let mutex = Mutex::new(vec![1, 2, 3]);

    // MutexGuard 实现了 Deref
    let guard = mutex.lock().unwrap();
    println!("guard deref: {:?}", *guard);
    // guard 在离开作用域时自动释放锁

    // ============================================================================
    // 3. RwLock<T> - 读写锁
    // ============================================================================

    use std::sync::RwLock;

    let rwlock = RwLock::new(5);

    // 读取
    {
        let read = rwlock.read().unwrap();
        println!("read: {}", read);
    }

    // 写入
    {
        let mut write = rwlock.write().unwrap();
        *write *= 2;
        println!("write: {}", *write);
    }
}

// ============================================================================
// 7. OnceCell 和 OnceLock
// ============================================================================

fn once_cell_examples() {
    println!("\n================== OnceCell 和 OnceLock ==================");

    use std::sync::OnceLock;

    // OnceCell: 延迟初始化
    static CELL: OnceLock<i32> = OnceLock::new();

    // get_or_init 只执行一次初始化
    let value = CELL.get_or_init(|| {
        println!("初始化中...");
        42
    });
    println!("value: {}", value);

    // 再次调用不会触发初始化
    let value2 = CELL.get_or_init(|| {
        println!("这不会打印");
        0
    });
    println!("value2: {}", value2);

    // ============================================================================
    // 2. OnceLock (需要 Send + Sync)
    // ============================================================================

    use std::sync::OnceLock as AtomicOnceLock;

    static ATOMIC_CELL: AtomicOnceLock<Vec<i32>> = AtomicOnceLock::new();

    let data = ATOMIC_CELL.get_or_init(|| {
        vec![1, 2, 3]
    });
    println!("atomic data: {:?}", data);
}

// ============================================================================
// 8. Weak<T> - 弱引用
// ============================================================================

fn weak_examples() {
    println!("\n================== Weak<T> ==================");

    use std::rc::{Rc, Weak};

    // 创建带弱引用的树
    #[derive(Debug)]
    struct Node {
        value: i32,
        parent: Weak<Node>,
        children: Vec<Rc<Node>>,
    }

    let leaf = Rc::new(Node {
        value: 3,
        parent: Weak::new(),
        children: Vec::new(),
    });

    println!("leaf strong: {}, weak: {}",
             Rc::strong_count(&leaf),
             Rc::weak_count(&leaf));

    // 创建父节点，引用 leaf
    let branch = Rc::new(Node {
        value: 5,
        parent: Weak::new(),
        children: vec![Rc::clone(&leaf)],
    });

    // leaf 的父引用
    let leaf_parent = leaf.parent.upgrade();
    println!("leaf parent: {:?}", leaf_parent);
}

// ============================================================================
// 9. Box、Rc、Arc 对比
// ============================================================================

fn comparison() {
    println!("\n================== 智能指针对比 ==================");

    println!("【Box<T>】");
    println!("- 堆分配，有所有权");
    println!("- 单所有权，可变/不可变借用");
    println!("- 用于递归类型、trait 对象");
    println!();

    println!("【Rc<T>】");
    println!("- 引用计数，多所有权");
    println!("- 不可变借用");
    println!("- 仅适用于单线程");
    println!();

    println!("【Arc<T>】");
    println!("- 原子引用计数，多所有权");
    println!("- 不可变借用");
    println!("- 线程安全");
    println!();

    println!("【RefCell<T>】");
    println!("- 内部可变性");
    println!("- 运行时借用检查");
    println!("- 配合 Rc 使用");
    println!();

    println!("【Mutex<T>】");
    println!("- 互斥锁");
    println!("- 线程安全可变访问");
    println!("- 配合 Arc 使用");
    println!();

    println!("【选择指南】");
    println!("- 堆分配 + 单所有权 -> Box");
    println!("- 单线程多所有权 -> Rc<RefCell<T>>");
    println!("- 多线程多所有权 -> Arc<Mutex<T>>");
    println!("- 需要改变 Rc 内容 -> Rc<RefCell<T>>");
    println!("- 需要改变 Arc 内容 -> Arc<Mutex<T>>");
}

// ============================================================================
// 主函数
// ============================================================================

fn main() {
    box_examples();
    rc_examples();
    refcell_examples();
    arc_examples();
    cell_examples();
    mutex_examples();
    once_cell_examples();
    weak_examples();
    comparison();

    println!("\n================== 智能指针总结 ==================");
    println!();
    println!("【Box<T>】");
    println!("- 堆分配，单所有权");
    println!("- 用于递归类型、trait 对象");
    println!();
    println!("【Rc<T> / Arc<T>】");
    println!("- 引用计数，多所有权");
    println!("- Rc: 单线程，Arc: 多线程");
    println!();
    println!("【RefCell<T> / Mutex<T>】");
    println!("- 内部可变性");
    println!("- RefCell: 单线程运行时检查");
    println!("- Mutex: 多线程锁");
    println!();
    println!("【组合模式】");
    println!("- Rc<RefCell<T>>: 单线程多所有权可变");
    println!("- Arc<Mutex<T>>: 多线程多所有权可变");
    println!("- Arc<RwLock<T>>: 多线程读写锁");
}

// =============================================================================
// Rust 学习示例 15: 闭包 (Closures)
// =============================================================================
// 闭包是可以在其定义的作用域中捕获变量的匿名函数
// 本文件将详细介绍闭包的语法、捕获机制和高级用法

// ============================================================================
// 1. 闭包基础语法
// ============================================================================

fn closure_basics() {
    println!("================== 闭包基础 ==================");

    // 闭包语法
    // |params| -> return_type { body }

    // 完整类型标注
    let add_one_v1 = |x: i32| -> i32 { x + 1 };

    // 省略返回类型（可推断）
    let add_one_v2 = |x: i32| { x + 1 };

    // 单表达式可省略大括号
    let add_one_v3 = |x: i32| x + 1;

    // 无参数
    let get_five = || 5;

    // 多个参数
    let add = |a, b| a + b;

    println!("add_one_v1(5) = {}", add_one_v1(5));
    println!("add_one_v3(5) = {}", add_one_v3(5));
    println!("get_five() = {}", get_five());
    println!("add(2, 3) = {}", add(2, 3));

    // ============================================================================
    // 2. 闭包调用
    // ============================================================================

    let mut c = || println!("闭包被调用");
    c();  // 调用闭包
    c();  // 再次调用

    // 带返回值的闭包
    let square = |x: i32| -> i32 { x * x };
    let result = square(5);
    println!("square(5) = {}", result);
}

// ============================================================================
// 2. 闭包与所有权
// ============================================================================
// 闭包可以以三种方式捕获环境变量：
// 1. 借用 (Immutable borrow) - &T
// 2. 可变借用 (Mutable borrow) - &mut T
// 3. 获取所有权 (Move) - T

fn closure_and_ownership() {
    println!("\n================== 闭包与所有权 ==================");

    // ============================================================================
    // 3. 不可变借用捕获
    // ============================================================================

    let x = 4;
    let equal_to_x = |y| y == x;  // 闭包借用 x
    println!("4 == 4: {}", equal_to_x(4));
    println!("x 在闭包后仍可用: {}", x);

    // ============================================================================
    // 4. 可变借用捕获
    // ============================================================================

    let mut count = 0;
    let mut increment = || {
        count += 1;
        count
    };

    println!("第一次调用: {}", increment());
    println!("第二次调用: {}", increment());
    // println!("count: {}", count);  // 错误！count 被可变借用

    let mut count = 0;
    {
        let mut inc = || {
            count += 1;
            count
        };
        println!("闭包内: {}", inc());
    }
    println!("闭包后 count: {}", count);

    // ============================================================================
    // 5. 获取所有权 (move 关键字)
    // ============================================================================

    let s = String::from("hello");

    // move 强制闭包获取所有权
    let closure = move || {
        println!("闭包内: {}", s);  // s 被移动到闭包内
    };

    closure();
    // println!("{}", s);  // 错误！s 已被移动

    // 混合使用
    let x = 5;
    let print_and_return = move || {
        println!("x = {}", x);  // x 被移动
        x  // 返回 x 的值
    };
    let y = print_and_return();
    println!("y = {}", y);
    // println!("{}", x);  // 错误！x 已被移动

    // ============================================================================
    // 6. Copy 类型 vs Move 类型
    // ============================================================================

    let x = 5;  // i32 是 Copy
    let closure = move || {
        println!("x = {}", x);  // x 被复制（Copy）而不是移动
    };
    closure();
    println!("x 在闭包后仍可用: {}", x);  // x 仍然有效
}

// ============================================================================
// 3. Fn, FnMut, FnOnce traits
// ============================================================================
// Rust 闭包实现以下三个 trait 之一：
// - FnOnce: 获取所有权，只能调用一次
// - FnMut: 可变借用，可调用多次
// - Fn: 不可变借用，可调用多次

fn closure_traits() {
    println!("\n================== Fn/FnMut/FnOnce ==================");

    // FnOnce - 获取环境变量的所有权
    fn consume<F>(closure: F)
    where
        F: FnOnce(),
    {
        closure();  // closure 被消费
    }

    let s = String::from("hello");
    consume(move || println!("{}", s));  // s 被移动
    // consume(|| println!("{}", s));  // 错误！s 已被移动

    // FnMut - 修改环境变量
    fn mutate<F>(mut closure: F)
    where
        F: FnMut(),
    {
        closure();
        closure();
    }

    let mut count = 0;
    mutate(|| count += 1);
    println!("count: {}", count);

    // Fn - 只读取环境变量
    fn access<F>(closure: F)
    where
        F: Fn() -> i32,
    {
        println!("result: {}", closure());
    }

    let x = 5;
    access(|| x * 2);

    // ============================================================================
    // trait 约束使用
    // ============================================================================

    // 使用泛型
    fn call_fn<F>(f: F) -> i32
    where
        F: Fn() -> i32,
    {
        f()
    }

    println!("call_fn: {}", call_fn(|| 42));

    // 使用 trait 对象
    fn call_fn_box(f: Box<dyn Fn() -> i32>) -> i32 {
        f()
    }

    println!("call_fn_box: {}", call_fn_box(Box::new(|| 100)));

    // 闭包自动实现对应的 trait
    let add = |a: i32, b: i32| a + b;
    println!("add 是 Fn: {}", call_fn(|| add(2, 3)));
}

// ============================================================================
// 4. 闭包作为参数和返回值
// ============================================================================

fn closure_as_parameter() {
    println!("\n================== 闭包作为参数 ==================");

    // 闭包作为参数
    fn apply<F>(f: F) -> i32
    where
        F: FnOnce(i32) -> i32,
    {
        f(5)
    }

    let result = apply(|x| x * 2);
    println!("apply: {}", result);

    // 带生命周期的闭包参数
    fn apply_with_lifetime<F>(f: F)
    where
        F: Fn(&[i32]) -> i32,
    {
        let numbers = vec![1, 2, 3];
        println!("sum: {}", f(&numbers));
    }

    apply_with_lifetime(|arr| arr.iter().sum());

    // FnMut 作为参数
    fn update<F>(mut f: F)
    where
        F: FnMut(),
    {
        f();
        f();
    }

    let mut counter = 0;
    update(|| counter += 1);
    println!("counter: {}", counter);
}

fn closure_as_return() {
    println!("\n================== 闭包作为返回值 ==================");

    // 返回闭包
    fn make_adder(n: i32) -> impl Fn(i32) -> i32 {
        move |x| x + n
    }

    let add_5 = make_adder(5);
    let add_10 = make_adder(10);

    println!("add_5(3) = {}", add_5(3));
    println!("add_10(3) = {}", add_10(3));

    // 返回 FnMut
    fn make_counter() -> impl FnMut() -> i32 {
        let mut count = 0;
        move || {
            count += 1;
            count
        }
    }

    let mut counter = make_counter();
    println!("counter(): {}", counter());
    println!("counter(): {}", counter());
    println!("counter(): {}", counter());

    // 返回 boxed 闭包
    fn make_multiplier(factor: i32) -> Box<dyn Fn(i32) -> i32> {
        Box::new(move |x| x * factor)
    }

    let triple = make_multiplier(3);
    println!("triple(4) = {}", triple(4));
}

// ============================================================================
// 5. 闭包与迭代器
// ============================================================================

fn closure_with_iterators() {
    println!("\n================== 闭包与迭代器 ==================");

    let numbers = vec![1, 2, 3, 4, 5];

    // map 使用闭包
    let doubled: Vec<_> = numbers.iter().map(|x| x * 2).collect();
    println!("map: {:?}", doubled);

    // filter 使用闭包
    let evens: Vec<_> = numbers.iter().filter(|x| *x % 2 == 0).collect();
    println!("filter: {:?}", evens);

    // 自定义比较
    let mut words = vec!["apple", "pie", "hello", "world"];
    words.sort_by(|a, b| a.len().cmp(&b.len()));
    println!("按长度排序: {:?}", words);

    // fold 使用闭包
    let sum = numbers.iter().fold(0, |acc, x| acc + x);
    println!("fold sum: {}", sum);

    // 组合多个闭包
    let result: Vec<_> = (1..=10)
        .filter(|x| x % 2 == 0)
        .map(|x| x * x)
        .take(3)
        .collect();
    println!("组合: {:?}", result);
}

// ============================================================================
// 6. 高阶函数示例
// ============================================================================

fn higher_order_functions() {
    println!("\n================== 高阶函数 ==================");

    // compose: f ∘ g = f(g(x))
    fn compose<A, B, C, F, G>(f: F, g: G) -> impl Fn(A) -> C
    where
        F: Fn(B) -> C,
        G: Fn(A) -> B,
    {
        move |x| f(g(x))
    }

    let double = |x: i32| x * 2;
    let square = |x: i32| x * x;

    let double_then_square = compose(square, double);
    println!("(2 * 2)^2 = {}", double_then_square(2));

    // flip: 交换参数顺序
    fn flip<F, A, B, C>(f: F) -> impl Fn(B, A) -> C
    where
        F: Fn(A, B) -> C,
    {
        move |a, b| f(b, a)
    }

    let div = |a: i32, b: i32| a / b;
    let flipped_div = flip(div);
    println!("10 / 2 = {}", div(10, 2));
    println!("10 / 2 (flipped) = {}", flipped_div(2, 10));

    // curry: 将二元函数转换为一元函数
    fn curry<F, A, B, C>(f: F) -> impl Fn(A) -> Box<dyn Fn(B) -> C>
    where
        F: Fn(A, B) -> C,
    {
        move |a| {
            let f = f.clone();
            Box::new(move |b| f(a, b))
        }
    }

    // 注意：完整的 curry 实现需要 Clone
}

// ============================================================================
// 7. 闭包与结构体
// ============================================================================

struct Calculator<T>
where
    T: Fn(i32, i32) -> i32,
{
    operation: T,
}

impl<T> Calculator<T>
where
    T: Fn(i32, i32) -> i32,
{
    fn new(operation: T) -> Self {
        Calculator { operation }
    }

    fn calculate(&self, a: i32, b: i32) -> i32 {
        (self.operation)(a, b)
    }
}

fn closure_with_structs() {
    println!("\n================== 闭包与结构体 ==================");

    let add_calc = Calculator::new(|a, b| a + b);
    let mul_calc = Calculator::new(|a, b| a * b);

    println!("add_calc.calculate(5, 3) = {}", add_calc.calculate(5, 3));
    println!("mul_calc.calculate(5, 3) = {}", mul_calc.calculate(5, 3));

    // 闭包缓存
    struct Cached<F>
    where
        F: Fn() -> i32,
    {
        computation: F,
        cached_value: Option<i32>,
    }

    impl<F> Cached<F>
    where
        F: Fn() -> i32,
    {
        fn new(computation: F) -> Self {
            Cached {
                computation,
                cached_value: None,
            }
        }

        fn get(&mut self) -> i32 {
            match self.cached_value {
                Some(v) => v,
                None => {
                    let v = (self.computation)();
                    self.cached_value = Some(v);
                    v
                }
            }
        }
    }

    let mut cached = Cached::new(|| {
        println!("计算中...");
        42
    });

    println!("第一次调用: {}", cached.get());
    println!("第二次调用: {}", cached.get());
}

// ============================================================================
// 8. 闭包与 Option/Result
// ============================================================================

fn closure_with_option_result() {
    println!("\n================== 闭包与 Option/Result ==================");

    // Option 的闭包方法
    let number: Option<i32> = Some(5);

    // map
    let doubled = number.map(|x| x * 2);
    println!("map: {:?}", doubled);

    // and_then
    let result = number.and_then(|x| if x > 0 { Some(x) } else { None });
    println!("and_then: {:?}", result);

    // unwrap_or_else
    let value = None.unwrap_or_else(|| {
        println!("计算默认值...");
        42
    });
    println!("unwrap_or_else: {}", value);

    // Result 的闭包方法
    let ok: Result<i32, &str> = Ok(5);

    // map
    let doubled = ok.map(|x| x * 2);
    println!("Result map: {:?}", doubled);

    // map_err
    let mapped_err = ok.map_err(|e| format!("Error: {}", e));
    println!("map_err: {:?}", mapped_err);

    // and_then
    let result = ok.and_then(|x| Ok(x * x));
    println!("and_then: {:?}", result);

    // or_else
    let err: Result<i32, &str> = Err("error");
    let recovered = err.or_else(|_| Ok(0));
    println!("or_else: {:?}", recovered);
}

// ============================================================================
// 9. 闭包与并发
// ============================================================================

fn closure_with_threads() {
    println!("\n================== 闭包与线程 ==================");

    use std::thread;

    // spawn 使用闭包创建线程
    let handle = thread::spawn(|| {
        println!("新线程执行");
    });
    handle.join().unwrap();

    // 共享数据需要 move
    let data = vec![1, 2, 3];
    let handle = thread::spawn(move || {
        println!("data: {:?}", data);
    });
    handle.join().unwrap();
    // println!("{:?}", data);  // 错误！data 已被移动

    // 闭包捕获与线程
    let numbers = vec![1, 2, 3, 4, 5];
    let sum = numbers.iter().sum::<i32>();

    let handle = thread::spawn(move || {
        // 闭包捕获 sum（Copy）
        sum * 2
    });

    let doubled = handle.join().unwrap();
    println!("doubled sum: {}", doubled);
}

// ============================================================================
// 10. 闭包最佳实践
// ============================================================================

fn best_practices() {
    println!("\n================== 闭包最佳实践 ==================");

    // 1. 优先使用 impl Fn 而非具体闭包类型
    fn process<F>(f: F) -> i32
    where
        F: Fn() -> i32,
    {
        f()
    }

    // 2. 使用 move 明确所有权转移
    let data = vec![1, 2, 3];
    let sum = || {
        let data = data;  // 显式移动
        data.iter().sum::<i32>()
    };
    println!("sum: {}", sum());

    // 3. 避免长时间捕获大型数据结构
    // 如果闭包可能存活很久，考虑 clone 必要的数据

    // 4. 使用 || 简写单表达式闭包
    let v = vec![1, 2, 3];
    let sum: i32 = v.iter().sum();  // 使用方法引用而非闭包

    // 5. 方法引用
    let numbers = vec![1, 2, 3, 4, 5];
    let max = numbers.iter().cloned().max();
    println!("max: {:?}", max);
}

// ============================================================================
// 主函数
// ============================================================================

fn main() {
    closure_basics();
    closure_and_ownership();
    closure_traits();
    closure_as_parameter();
    closure_as_return();
    closure_with_iterators();
    higher_order_functions();
    closure_with_structs();
    closure_with_option_result();
    closure_with_threads();
    best_practices();

    println!("\n================== 闭包总结 ==================");
    println!();
    println!("【闭包语法】");
    println!("- |params| -> return_type {{ body }}");
    println!("- 可省略类型标注和 return");
    println!();
    println!("【捕获方式】");
    println!("- 默认: 不可变借用 (&T)");
    println!("- mut: 可变借用 (&mut T)");
    println!("- move: 获取所有权 (T)");
    println!();
    println!("【Fn traits】");
    println!("- Fn: 不可变借用，可多次调用");
    println!("- FnMut: 可变借用，可多次调用");
    println!("- FnOnce: 获取所有权，仅一次调用");
    println!();
    println!("【使用场景】");
    println!("- 迭代器方法 (map, filter, fold)");
    println!("- 回调函数");
    println!("- 延迟计算");
    println!("- 线程并发");
    println!();
    println!("【最佳实践】");
    println!("- 优先使用 impl Fn 而非具体类型");
    println!("- 需要所有权时使用 move");
    println!("- 闭包简短时使用 || 语法糖");
}

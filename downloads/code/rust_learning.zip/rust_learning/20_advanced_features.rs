// =============================================================================
// Rust 学习示例 20: 高级特性总结
// =============================================================================
// 本文件总结 Rust 的高级特性，包括宏、类型系统、并发等

// ============================================================================
// 1. 宏系统
// ============================================================================

// 1.1 声明宏 (macro_rules!)
// 用于创建类似函数的宏

macro_rules! vec {
    // 空向量
    () => {
        Vec::new()
    };
    // 单个元素
    ($elem:expr) => {
        {
            let mut v = Vec::new();
            v.push($elem);
            v
        }
    };
    // 多个元素
    ($($elem:expr),+ $(,)?) => {
        {
            let mut v = Vec::new();
            $(v.push($elem);)+
            v
        }
    };
}

macro_rules! min {
    ($a:expr, $b:expr) => {
        if $a < $b {
            $a
        } else {
            $b
        }
    };
}

// 1.2 过程宏
// - #[derive(...)] - 派生宏
// - #[attribute] - 属性宏
// - fn!(...) - 函数宏

fn macro_examples() {
    println!("================== 宏系统 ==================");

    // 使用声明宏
    let v1: Vec<i32> = vec![];
    let v2 = vec![1, 2, 3];
    let v3 = vec![1, 2, 3,];  // 可选尾随逗号

    println!("vec![]: {:?}", v1);
    println!("vec![1,2,3]: {:?}", v2);

    // min! 宏
    println!("min!(3, 5) = {}", min!(3, 5));

    // 标准库宏
    println!("println! 是一个宏");
    println!("{:#?}", v2);  // 调试格式

    // ============================================================================
    // 2. concat!, stringif!, line!, column!, file!
    // ============================================================================

    println!("文件: {}", file!());
    println!("行号: {}", line!());
    println!("列号: {}", column!());

    const VERSION: &str = concat!("v", env!("CARGO_PKG_VERSION"));
    println!("版本: {}", VERSION);
}

// ============================================================================
// 2. 派生宏 (Derive Macros)
// ============================================================================

// 常见的派生宏
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
struct Config {
    name: String,
    enabled: bool,
}

impl Config {
    fn new(name: &str) -> Self {
        Config {
            name: name.to_string(),
            enabled: true,
        }
    }
}

fn derive_macros() {
    println!("\n================== 派生宏 ==================");

    let config = Config::new("app");
    println!("Debug: {:?}", config);
    println!("Clone: {:?}", config.clone());

    let config2 = config;
    println!("Copy: {:?}", config2);

    let config3 = Config::default();
    println!("Default: {:?}", config3);

    println!("PartialEq: {}", config == config2);
}

// ============================================================================
// 3. 类型别名与关联类型
// ============================================================================

// 类型别名
type Kilometers = i32;
type Result<T> = std::result::Result<T, std::io::Error>;
type Thunk = Box<dyn Fn() + Send + 'static>;

fn type_aliases() {
    println!("\n================== 类型别名 ==================");

    let distance: Kilometers = 100;
    println!("距离: {} 公里", distance);

    let thunk: Thunk = Box::new(|| println!("thunk"));
    thunk();
}

// ============================================================================
// 4. 新类型模式
// ============================================================================

struct Meters(i32);
struct Kilograms(i32);

fn newtype_pattern() {
    println!("\n================== 新类型模式 ==================");

    let meters = Meters(100);
    let kg = Kilograms(50);

    println!("米: {}", meters.0);
    println!("公斤: {}", kg.0);

    // 防止混淆
    // fn add(a: Meters, b: Meters) -> Meters { Meters(a.0 + b.0) }
    // add(meters, kg);  // 编译错误！
}

// ============================================================================
// 5. Sized 和 DST (动态大小类型)
// ============================================================================

fn sized_dst() {
    println!("\n================== Sized 和 DST ==================");

    // 固定大小类型
    println!("i32 是 Sized: {}", std::mem::size_of::<i32>());

    // str 是 DST（没有实现 Sized）
    // let s: str = "hello";  // 错误！str 没有确定大小

    // 必须通过引用使用 DST
    let s: &str = "hello";
    println!("&str 大小: {}", std::mem::size_of_val(s));

    // [T] 也是 DST
    let arr: &[i32] = &[1, 2, 3];
    println!("&[i32] 大小: {}", std::mem::size_of_val(arr));

    // 动态大小类型
    #[repr(C)]
    struct FatPointer {
        data: *const (),
        len: usize,
    }
    println!("胖指针大小: {}", std::mem::size_of::<FatPointer>());
}

// ============================================================================
// 6. Never 类型 (!)
// ============================================================================

fn never_type() {
    println!("\n================== Never 类型 ==================");

    // ! 表示永不返回（发散类型）
    fn forever() -> ! {
        loop {
            print!(".");
        }
    }

    // continue 和 return 也是 !
    let x: Option<i32> = None;

    let y: i32 = match x {
        Some(v) => v,
        None => return,  // 返回 !
    };

    // panic 也返回 !
    fn fail() -> ! {
        panic!("never returns")
    }
}

// ============================================================================
// 7. 特征对象进阶
// ============================================================================

trait Animal {
    fn speak(&self);
}

struct Dog;
struct Cat;

impl Animal for Dog {
    fn speak(&self) {
        println!("汪!");
    }
}

impl Animal for Cat {
    fn speak(&self) {
        println!("喵!");
    }
}

fn trait_objects_advanced() {
    println!("\n================== 特征对象进阶 ==================");

    // 创建特征对象向量
    let animals: Vec<Box<dyn Animal>> = vec![
        Box::new(Dog),
        Box::new(Cat),
        Box::new(Dog),
    ];

    for animal in &animals {
        animal.speak();
    }

    // ============================================================================
    // 2. 返回特征对象
    // ============================================================================

    fn create_animal(name: &str) -> Box<dyn Animal> {
        match name {
            "dog" => Box::new(Dog),
            "cat" => Box::new(Cat),
            _ => Box::new(Dog),
        }
    }

    let animal = create_animal("cat");
    animal.speak();

    // ============================================================================
    // 3. 对象安全的 trait
    // ============================================================================

    // 对象安全的 trait 可以作为 dyn Trait 使用
    // 规则：
    // 1. 不包含泛型方法
    // 2. Self 不是参数类型
    // 3. 没有静态方法

    trait Simple {
        fn method(&self);
    }

    // 可以作为 dyn Simple 使用
    let simple: Box<dyn Simple> = Box::new(());
}

// ============================================================================
// 8. 闭包进阶
// ============================================================================

fn closures_advanced() {
    println!("\n================== 闭包进阶 ==================");

    // Fn, FnMut, FnOnce 的关系
    // Fn: FnMut + Clone
    // FnMut: FnOnce + &mut self

    // 闭包实现多个 trait
    let closure = |x: i32| x + 1;
    // closure 是 Fn, FnMut, FnOnce

    // 使用泛型约束
    fn apply<F>(f: F) -> i32
    where
        F: Fn(i32) -> i32 + FnMut + FnOnce,
    {
        f(5)
    }

    println!("apply: {}", apply(|x| x * 2));

    // 闭包作为返回值
    fn make_adder(n: i32) -> impl Fn(i32) -> i32 {
        move |x| x + n
    }

    let add5 = make_adder(5);
    println!("add5(10) = {}", add5(10));
}

// ============================================================================
// 9. 异步编程基础
// ============================================================================

// 使用 async/await 需要启用特性
// #![feature(async_closure)]

fn async_basics() {
    println!("\n================== 异步编程基础 ==================");

    // Rust 的 async/await 是实验性功能
    // 稳定版本需要使用 tokio 等异步运行时

    // 简单示例（需要 nightly）
    // async fn fetch_data() -> String {
    //     // 模拟异步操作
    //     String::from("data")
    // }

    // #[tokio::main]
    // async fn main() {
    //     let data = fetch_data().await;
    //     println!("{}", data);
    // }

    println!("异步编程需要 tokio 或 async-std 运行时");
    println!("示例:");
    println!("[dependencies]");
    println!("tokio = {{ version = \"1\", features = [\"full\"] }}");
}

// ============================================================================
// 10. 并发编程
// ============================================================================

fn concurrency_basics() {
    println!("\n================== 并发编程 ==================");

    use std::thread;
    use std::sync::{Arc, Mutex};

    // 创建线程
    let handle = thread::spawn(|| {
        println!("新线程");
    });
    handle.join().unwrap();

    // 共享状态
    let counter = Arc::new(Mutex::new(0));

    let counter_clone = Arc::clone(&counter);
    let handle = thread::spawn(move || {
        let mut num = counter_clone.lock().unwrap();
        *num += 1;
    });

    handle.join().unwrap();
    println!("计数器: {}", *counter.lock().unwrap());

    // ============================================================================
    // 2. Send 和 Sync
    // ============================================================================

    // Send: 可以在线程间传递所有权
    // Sync: 可以在线程间传递引用

    // 大多数类型自动实现 Send 和 Sync
    // Rc, Cell, RefCell 手动实现（不是线程安全的）

    println!("i32 是 Send: {}", std::marker::Send);
    println!("i32 是 Sync: {}", std::marker::Sync);

    // ============================================================================
    // 3. Channel
    // ============================================================================

    use std::sync::mpsc;

    let (tx, rx) = mpsc::channel();

    thread::spawn(move || {
        tx.send(42).unwrap();
    });

    let received = rx.recv().unwrap();
    println!("收到消息: {}", received);
}

// ============================================================================
// 11. 迭代器进阶
// ============================================================================

fn iterator_advanced() {
    println!("\n================== 迭代器进阶 ==================");

    // 组合多个迭代器
    let result: Vec<_> = (1..=100)
        .filter(|x| x % 2 == 0)           // 偶数
        .map(|x| x * x)                    // 平方
        .take(5)                           // 前5个
        .collect();

    println!("结果: {:?}", result);

    // ============================================================================
    // 2. FromIterator
    // ============================================================================

    // 从迭代器构建任何实现了 FromIterator 的类型
    let text = "hello world";
    let char_count = text.chars().count();
    println!("字符数: {}", char_count);

    // ============================================================================
    // 3. 自定义迭代器
    // ============================================================================

    struct Fibonacci {
        current: u64,
        next: u64,
    }

    impl Fibonacci {
        fn new() -> Self {
            Fibonacci { current: 0, next: 1 }
        }
    }

    impl Iterator for Fibonacci {
        type Item = u64;

        fn next(&mut self) -> Option<Self::Item> {
            let current = self.current;
            self.current = self.next;
            self.next = current + self.next;
            Some(current)
        }
    }

    let fib: Vec<_> = Fibonacci::new().take(10).collect();
    println!("Fibonacci: {:?}", fib);
}

// ============================================================================
// 12. 反射 (Reflection)
// ============================================================================

fn reflection() {
    println!("\n================== 反射 ==================");

    // Rust 不像 Java 那样有完整的反射
    // 但可以使用 std::any 提供部分反射功能

    use std::any::{Any, type_name};

    let x: i32 = 42;
    let s: String = String::from("hello");

    println!("x 类型: {}", type_name::<i32>());
    println!("s 类型: {}", type_name::<String>());

    // Any 可以存储任何类型
    let boxed: Box<dyn Any> = Box::new(42);
    if let Some(n) = boxed.downcast_ref::<i32>() {
        println!("downcast 成功: {}", n);
    }

    // ============================================================================
    // 2. std::any::type_name
    // ============================================================================

    fn print_type<T>(_: T) {
        println!("类型: {}", std::any::type_name::<T>());
    }

    print_type(42);
    print_type("hello");
    print_type(vec![1, 2, 3]);
}

// ============================================================================
// 13. 编译时计算
// ============================================================================

fn compile_time() {
    println!("\n================== 编译时计算 ==================");

    // const 泛型
    fn sum_array<T: std::ops::Add<Output = T> + Copy, const N: usize>(arr: [T; N]) -> T {
        let mut result = arr[0];
        for i in 1..N {
            result = result + arr[i];
        }
        result
    }

    let arr = [1, 2, 3, 4, 5];
    println!("数组和: {}", sum_array(arr));

    // ============================================================================
    // 2. const fn
    // ============================================================================

    const fn gcd(mut a: u64, mut b: u64) -> u64 {
        while b != 0 {
            let t = b;
            b = a % b;
            a = t;
        }
        a
    }

    const GCD_RESULT: u64 = gcd(48, 18);
    println!("编译时 GCD: {}", GCD_RESULT);
}

// ============================================================================
// 14. Pin 和 Unpin
// ============================================================================

fn pin_unpin() {
    println!("\n================== Pin 和 Unpin ==================");

    // 大多数类型是 Unpin
    // Pin 用于包装那些不能被移动的类型

    use std::pin::Pin;
    use std::marker::PhantomPinned;

    // 栈分配的固定结构
    let mut x = 5;
    let pin_x = Pin::new(&mut x);
    println!("Pin 示例: {}", *pin_x);

    // PhantomPinned 不能被移动
    struct Pinned {
        data: String,
        _pinned: PhantomPinned,
    }

    println!("PhantomPinned 类型大小: {}", std::mem::size_of::<PhantomPinned>());
}

// ============================================================================
// 主函数
// ============================================================================

fn main() {
    macro_examples();
    derive_macros();
    type_aliases();
    newtype_pattern();
    sized_dst();
    never_type();
    trait_objects_advanced();
    closures_advanced();
    async_basics();
    concurrency_basics();
    iterator_advanced();
    reflection();
    compile_time();
    pin_unpin();

    println!("\n================== 高级特性总结 ==================");
    println!();
    println!("【宏系统】");
    println!("- macro_rules! - 声明宏");
    println!("- #[derive(...)] - 派生宏");
    println!("- 编译时元编程");
    println!();
    println!("【类型系统】");
    println!("- 类型别名");
    println!("- 新类型模式");
    println!("- Sized 和 DST");
    println!("- Never 类型 !");
    println!();
    println!("【并发】");
    println!("- Send 和 Sync");
    println!("- Arc, Mutex, Channel");
    println!("- 线程和并行");
    println!();
    println!("【高级迭代】");
    println!("- FromIterator");
    println!("- 自定义迭代器");
    println!("- 迭代器适配器组合");
    println!();
    println!("【编译时计算】");
    println!("- const fn");
    println!("- 编译时求值");
    println!();
    println!("【建议学习路径】");
    println!("1. 掌握基础语法");
    println!("2. 理解所有权和生命周期");
    println!("3. 熟练使用 trait 和泛型");
    println!("4. 学习并发编程");
    println!("5. 探索宏和元编程");
    println!("6. 实践项目开发");
}

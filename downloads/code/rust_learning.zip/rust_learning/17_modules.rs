// =============================================================================
// Rust 学习示例 17: 模块系统 (Modules)
// =============================================================================
// Rust 的模块系统用于组织代码、控制可见性和创建包
// 本文件将详细介绍模块、crate、package 的概念和使用

// ============================================================================
// 1. 模块基础
// ============================================================================

// 使用 mod 关键字定义模块
mod math {
    // 模块内的函数
    pub fn add(a: i32, b: i32) -> i32 {
        a + b
    }

    // 私有函数（默认）
    fn subtract(a: i32, b: i32) -> i32 {
        a - b
    }

    // 公开模块内的私有模块
    pub mod advanced {
        pub fn multiply(a: i32, b: i32) -> i32 {
            a * b
        }

        fn divide(a: i32, b: i32) -> i32 {
            a / b
        }
    }
}

fn module_basics() {
    println!("================== 模块基础 ==================");

    // 使用 :: 访问模块成员
    println!("add: {}", math::add(5, 3));
    println!("multiply: {}", math::advanced::multiply(5, 3));

    // 私有函数不能从外部访问
    // println!("{}", math::subtract(5, 3));  // 错误！
}

// ============================================================================
// 2. pub 可见性
// ============================================================================

mod visibility {
    // 默认是私有的
    struct PrivateStruct {
        pub field: i32,  // 字段可以单独公开
        field2: i32,
    }

    // pub 整个结构体
    pub struct PublicStruct {
        pub field: i32,
        pub field2: i32,
    }

    // 枚举默认所有变体都是公开的
    pub enum Color {
        Red,
        Green,
        Blue,
    }

    // 枚举可以选择性公开变体
    enum PrivateEnum {
        PublicVariant,
        // PrivateVariant,  // 默认私有
    }

    pub enum PublicEnum {
        PublicVariant,
    }
}

fn visibility_examples() {
    println!("\n================== pub 可见性 ==================");

    use visibility::{Color, PublicStruct};

    // 枚举可以直接使用
    let color = Color::Red;
    println!("枚举: {:?}", color);

    // 结构体需要使用 pub 字段
    let s = PublicStruct { field: 10, field2: 20 };
    println!("结构体字段: {}, {}", s.field, s.field2);

    // 结构体内部可以访问私有字段
    // let p = visibility::PrivateStruct { field: 10, field2: 20 };
    // 错误！结构体本身是私有的
}

// ============================================================================
// 3. use 语句
// ============================================================================

mod use_statements {
    pub mod outer {
        pub mod inner {
            pub const VALUE: i32 = 42;
            pub fn function() -> i32 { 42 }
        }
    }

    // 绝对路径导入
    use crate::use_statements::outer::inner::VALUE;
    use crate::use_statements::outer::inner::function;

    // 相对路径导入
    use self::outer::inner::VALUE as REL_VALUE;

    // pub use 重新导出
    pub use outer::inner::VALUE as REEXPORTED;

    // use 枚举变体
    pub enum Shape {
        Circle(f64),
        Rectangle(f64, f64),
    }

    use Shape::{Circle, Rectangle};

    // use glob
    use Shape::*;
}

fn use_statements() {
    println!("\n================== use 语句 ==================");

    // 使用 use 导入
    println!("VALUE: {}", use_statements::VALUE);
    println!("REL_VALUE: {}", use_statements::REL_VALUE);

    // 使用重新导出的值
    println!("REEXPORTED: {}", use_statements::REExPORTED);

    // 枚举变体
    use use_statements::Shape::{Circle, Rectangle};
    let circle = Circle(5.0);
    let rect = Rectangle(10.0, 20.0);
    println!("圆形: {:?}", circle);
    println!("矩形: {:?}", rect);
}

// ============================================================================
// 4. 结构体中的 pub
// ============================================================================

mod struct_visibility {
    pub struct Config {
        pub url: String,           // 公开字段
        pub timeout: u64,          // 公开字段
        retries: u32,              // 私有字段（只能内部修改）
    }

    impl Config {
        // 构造函数
        pub fn new(url: String) -> Self {
            Config {
                url,
                timeout: 30,
                retries: 3,
            }
        }

        // 提供设置器
        pub fn set_timeout(&mut self, timeout: u64) {
            self.timeout = timeout;
        }

        pub fn set_retries(&mut self, retries: u32) {
            self.retries = retries;
        }

        // 提供 getter
        pub fn retries(&self) -> u32 {
            self.retries
        }
    }
}

fn struct_visibility_example() {
    println!("\n================== 结构体可见性 ==================");

    let mut config = struct_visibility::Config::new(String::from("https://api.example.com"));

    println!("URL: {}", config.url);
    println!("Timeout: {}", config.timeout);
    println!("Retries: {}", config.retries());

    config.set_timeout(60);
    println!("更新后 Timeout: {}", config.timeout);
}

// ============================================================================
// 5. 嵌套模块
// ============================================================================

mod outer_module {
    pub const PUBLIC: &str = "outer public";

    pub mod middle_module {
        pub const PUBLIC: &str = "middle public";

        pub mod inner_module {
            pub const PUBLIC: &str = "inner public";

            pub fn access_outer() {
                // 使用 super 访问父模块
                println!("super: {}", super::PUBLIC);
                println!("super::super: {}", super::super::PUBLIC);
            }
        }

        pub fn access_inner() {
            println!("self: {}", self::PUBLIC);
            inner_module::access_outer();
        }
    }

    pub fn access_middle() {
        println!("self: {}", self::PUBLIC);
        middle_module::access_inner();
    }
}

fn nested_modules() {
    println!("\n================== 嵌套模块 ==================");

    println!("outer: {}", outer_module::PUBLIC);
    println!("middle: {}", outer_module::middle_module::PUBLIC);
    println!("inner: {}", outer_module::middle_module::inner_module::PUBLIC);

    outer_module::access_middle();
}

// ============================================================================
// 6. self 和 super
// ============================================================================

mod self_super_demo {
    pub fn function() {
        println!("模块 function");
    }

    pub mod inner {
        pub fn function() {
            println!("inner function");
        }

        pub fn call_self() {
            self::function();  // 调用当前模块的 function
        }

        pub fn call_parent() {
            super::function();  // 调用父模块的 function
        }
    }
}

fn self_super() {
    println!("\n================== self 和 super ==================");

    self_super_demo::inner::call_self();
    self_super_demo::inner::call_parent();
}

// ============================================================================
// 7. 构造器模式 (Constructor Pattern)
// ============================================================================

mod builder_pattern {
    pub struct User {
        name: String,
        email: String,
        age: u32,
        active: bool,
    }

    impl User {
        // 公共构造函数
        pub fn new(name: String, email: String) -> Self {
            User {
                name,
                email,
                age: 0,
                active: true,
            }
        }

        // Builder 模式
        pub fn builder(name: String, email: String) -> UserBuilder {
            UserBuilder { name, email }
        }

        // Getter
        pub fn name(&self) -> &str {
            &self.name
        }

        pub fn email(&self) -> &str {
            &self.email
        }

        pub fn age(&self) -> u32 {
            self.age
        }

        pub fn is_active(&self) -> bool {
            self.active
        }
    }

    // Builder 结构体
    pub struct UserBuilder {
        name: String,
        email: String,
        age: Option<u32>,
        active: Option<bool>,
    }

    impl UserBuilder {
        pub fn age(mut self, age: u32) -> Self {
            self.age = Some(age);
            self
        }

        pub fn active(mut self, active: bool) -> Self {
            self.active = Some(active);
            self
        }

        pub fn build(self) -> User {
            User {
                name: self.name,
                email: self.email,
                age: self.age.unwrap_or(0),
                active: self.active.unwrap_or(true),
            }
        }
    }
}

fn builder_pattern_demo() {
    println!("\n================== Builder 模式 ==================");

    use builder_pattern::User;

    // 普通构造函数
    let user1 = User::new(
        String::from("Alice"),
        String::from("alice@example.com"),
    );
    println!("User1: {} ({}) age={}",
             user1.name(), user1.email(), user1.age());

    // Builder 模式
    let user2 = User::builder(
        String::from("Bob"),
        String::from("bob@example.com"),
    )
    .age(25)
    .active(true)
    .build();

    println!("User2: {} ({}) age={}",
             user2.name(), user2.email(), user2.age());
}

// ============================================================================
// 8. pub(crate) 和 pub(super)
// ============================================================================

mod crate_super_demo {
    // pub(crate) - 对当前 crate 公开，对外部不公开
    pub(crate) const CRATE_INTERNAL: &str = "crate internal";

    // pub(super) - 对父模块公开
    pub(super) const SUPER_INTERNAL: &str = "super internal";

    // pub(in path) - 对指定路径的模块公开
    pub(in crate::crate_super_demo) const LIMITED: &str = "limited visibility";
}

mod child {
    pub fn access_internal() {
        // 可以访问 pub(crate) 成员
        println!("{}", crate::crate_super_demo::CRATE_INTERNAL);
    }
}

fn visibility_modifiers() {
    println!("\n================== 可见性修饰符 ==================");

    // pub(crate) 可以从 crate 内部访问
    println!("crate_internal: {}", crate_super_demo::CRATE_INTERNAL);

    // 但不能从外部 crate 访问
    // extern crate 场景下不可用
}

// ============================================================================
// 9. 模块与文件组织
// ============================================================================

// 在实际项目中，模块通常放在单独的文件中
// 以下示例展示文件组织结构

// src/
// ├── main.rs
// ├── lib.rs
// ├── module1.rs
// ├── module2.rs
// └── nested/
//     ├── mod.rs
//     └── submod.rs

// lib.rs 或 main.rs 中声明子模块：
// mod nested;  // 引用 nested/mod.rs 或 nested.rs
// mod module1; // 引用 module1.rs

// nested/mod.rs 中声明子模块：
// pub mod submod;

// ============================================================================
// 10. 懒初始化模式
// ============================================================================

mod lazy_init {
    use std::cell::OnceCell;

    static CELL: OnceCell<String> = OnceCell::new();

    pub fn get_config() -> &'static String {
        CELL.get_or_init(|| {
            println!("初始化配置...");
            String::from("配置内容")
        })
    }
}

fn lazy_init_demo() {
    println!("\n================== 懒初始化 ==================");

    println!("第一次调用:");
    let config1 = lazy_init::get_config();
    println!("config: {}", config1);

    println!("第二次调用:");
    let config2 = lazy_init::get_config();
    println!("config: {}", config2);
}

// ============================================================================
// 11. 模块模式 - facade
// ============================================================================

mod facade_demo {
    // 内部模块
    mod database {
        pub fn connect() -> String {
            println!("连接数据库");
            String::from("Database Connection")
        }

        pub fn query(sql: &str) {
            println!("执行查询: {}", sql);
        }
    }

    mod cache {
        pub fn get(key: &str) -> Option<String> {
            println!("获取缓存: {}", key);
            Some(String::from("cached"))
        }

        pub fn set(key: &str, value: &str) {
            println!("设置缓存: {}={}", key, value);
        }
    }

    mod api {
        pub fn handle_request() {
            println!("处理请求");
        }
    }

    // Facade - 简化接口
    pub fn init_system() {
        database::connect();
        cache::set("initialized", "true");
    }

    pub fn process_request(sql: &str) {
        // 先查缓存
        if let Some(cached) = cache::get(sql) {
            println!("使用缓存: {}", cached);
            return;
        }

        // 缓存未命中，查询数据库
        database::query(sql);
        api::handle_request();
    }
}

fn facade_pattern() {
    println!("\n================== Facade 模式 ==================");

    facade_demo::init_system();
    facade_demo::process_request("SELECT * FROM users");
}

// ============================================================================
// 主函数
// ============================================================================

fn main() {
    module_basics();
    visibility_examples();
    use_statements();
    struct_visibility_example();
    nested_modules();
    self_super();
    builder_pattern_demo();
    visibility_modifiers();
    lazy_init_demo();
    facade_pattern();

    println!("\n================== 模块系统总结 ==================");
    println!();
    println!("【模块定义】");
    println!("- mod name {{ ... }} - 定义模块");
    println!("- mod name; - 从文件加载模块");
    println!();
    println!("【可见性】");
    println!("- pub - 公开");
    println!("- pub(crate) - crate 内部公开");
    println!("- pub(super) - 父模块公开");
    println!("- (无) - 私有");
    println!();
    println!("【路径】");
    println!("- :: 前缀 - 从 crate 根开始");
    println!("- self:: - 当前模块");
    println!("- super:: - 父模块");
    println!();
    println!("【导入】");
    println!("- use path - 导入");
    println!("- use path as alias - 重命名导入");
    println!("- pub use path - 重新导出");
    println!();
    println!("【最佳实践】");
    println!("- 公开 API 使用 pub");
    println!("- 内部实现保持私有");
    println!("- 使用 facade 简化复杂模块");
    println!("- 合理的模块层次结构");
}

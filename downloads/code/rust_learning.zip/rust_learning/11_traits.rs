// =============================================================================
// Rust 学习示例 11: Trait (特征)
// =============================================================================
// Trait 定义了共享的行为（类似于其他语言的接口）
// 本文件将详细介绍 trait 的定义、实现和高级用法

// ============================================================================
// 1. 基础 Trait 定义
// ============================================================================

// 定义一个 trait
trait Summary {
    fn summarize(&self) -> String;
}

// 为结构体实现 trait
struct Article {
    title: String,
    author: String,
    content: String,
}

impl Summary for Article {
    fn summarize(&self) -> String {
        format!("{} by {}", self.title, self.author)
    }
}

struct Tweet {
    username: String,
    content: String,
}

impl Summary for Tweet {
    fn summarize(&self) -> String {
        format!("@{}: {}", self.username, self.content)
    }
}

fn trait_basics() {
    println!("================== Trait 基础 ==================");

    let article = Article {
        title: String::from("Rust Programming"),
        author: String::from("John Doe"),
        content: String::from("Rust is a systems programming language..."),
    };

    let tweet = Tweet {
        username: String::from("rustlang"),
        content: String::from("Rust 1.0 released!"),
    };

    println!("文章摘要: {}", article.summarize());
    println!("推文摘要: {}", tweet.summarize());
}

// ============================================================================
// 2. 默认实现
// ============================================================================

trait SummaryWithDefault {
    fn summarize_author(&self) -> String {
        String::from("(Unknown Author)")
    }

    fn summarize_full(&self) -> String {
        format!("{} - {}", self.summarize_author(), self.summarize_author())
    }
}

struct Book {
    title: String,
    author: String,
}

impl SummaryWithDefault for Book {
    // 可以覆盖默认实现
    fn summarize_author(&self) -> String {
        format!("Author: {}", self.author)
    }
}

fn default_implementation() {
    println!("\n================== 默认实现 ==================");

    let book = Book {
        title: String::from("The Rust Book"),
        author: String::from("Steve Klabnik"),
    };

    println!("作者: {}", book.summarize_author());
}

// ============================================================================
// 3. Trait 作为参数
// ============================================================================

// 使用 impl Trait 语法
fn notify_implicit(item: &impl Summary) {
    println!("通知: {}", item.summarize());
}

// 使用 trait bound 显式声明
fn notify_explicit<T: Summary>(item: &T) {
    println!("通知: {}", item.summarize());
}

// 多个 trait 约束
fn notify_multiple(item: &(impl Summary + std::fmt::Display)) {
    println!("{}", item);
    println!("摘要: {}", item.summarize());
}

// 使用 where 子句
fn notify_where<T>(item: &T)
where
    T: Summary + std::fmt::Debug,
{
    println!("{:?}", item);
    println!("摘要: {}", item.summarize());
}

fn trait_as_parameter() {
    println!("\n================== Trait 作为参数 ==================");

    let article = Article {
        title: String::from("Rust Programming"),
        author: String::from("John Doe"),
        content: String::from("Rust is..."),
    };

    notify_implicit(&article);
    notify_explicit(&article);
}

// ============================================================================
// 4. Trait 作为返回值
// ============================================================================

// 返回实现 trait 的类型
fn returns_summarizable() -> impl Summary {
    Tweet {
        username: String::from("rustlang"),
        content: String::from("Hello, world!"),
    }
}

fn trait_as_return() {
    println!("\n================== Trait 作为返回值 ==================");

    let item = returns_summarizable();
    println!("返回的摘要: {}", item.summarize());

    // 注意：impl Trait 只允许返回单一类型
    // 如果需要返回多种类型，使用 trait 对象
}

// ============================================================================
// 5. 使用 trait 对象实现多态
// ============================================================================

// 定义 trait
trait Drawable {
    fn draw(&self);
    fn area(&self) -> f64;
}

// 实现 trait
struct Circle {
    radius: f64,
}

impl Drawable for Circle {
    fn draw(&self) {
        println!("画圆，半径: {}", self.radius);
    }

    fn area(&self) -> f64 {
        std::f64::consts::PI * self.radius * self.radius
    }
}

struct Rectangle {
    width: f64,
    height: f64,
}

impl Drawable for Rectangle {
    fn draw(&self) {
        println!("画矩形: {}x{}", self.width, self.height);
    }

    fn area(&self) -> f64 {
        self.width * self.height
    }
}

fn trait_objects() {
    println!("\n================== Trait 对象 ==================");

    // 创建对象集合
    let shapes: Vec<Box<dyn Drawable>> = vec![
        Box::new(Circle { radius: 5.0 }),
        Box::new(Rectangle { width: 10.0, height: 20.0 }),
        Box::new(Circle { radius: 3.0 }),
    ];

    // 动态分发 - 运行时决定调用哪个方法
    let mut total_area = 0.0;
    for shape in &shapes {
        shape.draw();
        total_area += shape.area();
    }

    println!("总面积: {:.2}", total_area);
}

// ============================================================================
// 6. 泛型 trait（trait 泛型参数）
// ============================================================================

trait Container<Item> {
    fn add(&mut self, item: Item);
    fn get(&self, index: usize) -> Option<&Item>;
    fn len(&self) -> usize;
}

struct VecContainer<Item> {
    items: Vec<Item>,
}

impl<Item> VecContainer<Item> {
    fn new() -> Self {
        VecContainer { items: Vec::new() }
    }
}

impl<Item> Container<Item> for VecContainer<Item> {
    fn add(&mut self, item: Item) {
        self.items.push(item);
    }

    fn get(&self, index: usize) -> Option<&Item> {
        self.items.get(index)
    }

    fn len(&self) -> usize {
        self.items.len()
    }
}

fn generic_trait() {
    println!("\n================== 泛型 Trait ==================");

    let mut container = VecContainer::new();
    container.add(1);
    container.add(2);
    container.add(3);

    println!("容器长度: {}", container.len());
    println!("元素 0: {:?}", container.get(0));
}

// ============================================================================
// 7. 关联类型
// ============================================================================

trait Iterator2 {
    type Item;  // 关联类型

    fn next(&mut self) -> Option<Self::Item>;
}

struct Counter {
    current: u32,
    max: u32,
}

impl Counter {
    fn new(max: u32) -> Self {
        Counter { current: 0, max }
    }
}

impl Iterator2 for Counter {
    type Item = u32;

    fn next(&mut self) -> Option<Self::Item> {
        if self.current < self.max {
            self.current += 1;
            Some(self.current)
        } else {
            None
        }
    }
}

fn associated_types() {
    println!("\n================== 关联类型 ==================");

    let mut counter = Counter::new(5);
    let values: Vec<u32> = counter.collect();
    println!("计数器收集: {:?}", values);

    // 手动迭代
    let mut counter = Counter::new(3);
    while let Some(n) = counter.next() {
        print!("{} ", n);
    }
    println!();
}

// ============================================================================
// 8. supertrait
// ============================================================================

// 要求 Self 实现另一个 trait
trait Printable: std::fmt::Display {
    fn print_me(&self) {
        println!("{}", self);
    }
}

#[derive(Debug)]
struct Person {
    name: String,
}

impl std::fmt::Display for Person {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "Person({})", self.name)
    }
}

impl Printable for Person {}

fn supertrait_example() {
    println!("\n================== Supertrait ==================");

    let person = Person {
        name: String::from("Alice"),
    };

    person.print_me();
}

// ============================================================================
// 9. Blanket Implementation（空白实现）
// ============================================================================

// 为所有实现了某个 trait 的类型实现另一个 trait
trait Printable2 {
    fn print(&self);
}

// Blanket implementation
impl<T: std::fmt::Display> Printable2 for T {
    fn print(&self) {
        println!("{}", self);
    }
}

fn blanket_impl() {
    println!("\n================== 空白实现 ==================");

    42.print();
    "hello".print();
    3.14.print();
}

// ============================================================================
// 10. 常用标准库 Trait
// ============================================================================

fn standard_traits() {
    println!("\n================== 标准库常用 Trait ==================");

    // Debug - 用于 {:?} 格式化
    #[derive(Debug)]
    struct Point { x: i32, y: i32 }

    let p = Point { x: 10, y: 20 };
    println!("Debug: {:?}", p);

    // Clone - 深拷贝
    #[derive(Clone)]
    struct Cloneable { value: i32 }
    let c1 = Cloneable { value: 42 };
    let c2 = c1.clone();
    println!("Clone: {} and {}", c1.value, c2.value);

    // PartialEq - 相等比较
    #[derive(PartialEq)]
    struct Equal { x: i32 }
    let e1 = Equal { x: 10 };
    let e2 = Equal { x: 10 };
    println!("PartialEq: {} == {}", e1.x, e2.x);

    // Eq - 全等（用于需要完全相等的集合）
    // Eq 继承自 PartialEq，所有字段也必须实现 Eq

    // PartialOrd - 大小比较
    #[derive(PartialEq, PartialOrd)]
    struct Orderable { value: i32 }

    let o1 = Orderable { value: 10 };
    let o2 = Orderable { value: 20 };
    println!("PartialOrd: {} < {} = {}", o1.value, o2.value, o1 < o2);

    // Display - 用户友好的格式化
    // 需要手动实现

    // Default - 默认值
    #[derive(Default)]
    struct Defaults { x: i32, y: i32 }

    let d = Defaults::default();
    println!("Default: ({}, {})", d.x, d.y);

    // From 和 Into - 类型转换
    let num: i32 = 42;
    let big: i64 = num.into();  // From<T> for T 自动实现 Into
    println!("Into: {}", big);

    // AsRef 和 AsMut - 引用转换
    let s: &str = "hello";
    let owned: String = s.into();
    println!("Into String: {}", owned);
}

// ============================================================================
// 11. 手动实现 trait
// ============================================================================

use std::fmt;

struct Counter2 {
    value: u32,
}

impl fmt::Display for Counter2 {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "Counter({})", self.value)
    }
}

impl fmt::Debug for Counter2 {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Counter")
            .field("value", &self.value)
            .finish()
    }
}

impl Default for Counter2 {
    fn default() -> Self {
        Counter2 { value: 0 }
    }
}

impl Counter2 {
    fn new(value: u32) -> Self {
        Counter2 { value }
    }

    fn increment(&mut self) {
        self.value += 1;
    }
}

fn manual_trait_impl() {
    println!("\n================== 手动实现 Trait ==================");

    let counter = Counter2::new(42);
    println!("Display: {}", counter);
    println!("Debug: {:?}", counter);

    let default_counter = Counter2::default();
    println!("Default: {:?}", default_counter);
}

// ============================================================================
// 12. trait 与泛型结合
// ============================================================================

// 返回最大值的函数
fn largest<T: PartialOrd>(list: &[T]) -> &T {
    let mut largest = &list[0];

    for item in list {
        if item > largest {
            largest = item;
        }
    }

    largest
}

// 实现自定义 trait
trait Math {
    fn square(&self) -> Self;
    fn cube(&self) -> Self;
}

impl Math for i32 {
    fn square(&self) -> Self {
        self * self
    }

    fn cube(&self) -> Self {
        self * self * self
    }
}

impl Math for f64 {
    fn square(&self) -> Self {
        self * self
    }

    fn cube(&self) -> Self {
        self * self * self
    }
}

fn trait_with_generics() {
    println!("\n================== Trait 与泛型结合 ==================");

    println!("largest: {}", largest(&[1, 5, 3, 2, 4]));
    println!("largest: {}", largest(&[1.0, 5.0, 3.0]));

    println!("i32.square(): {}", 5.square());
    println!("i32.cube(): {}", 5.cube());
    println!("f64.square(): {}", 3.5.square());
}

// ============================================================================
// 主函数
// ============================================================================

fn main() {
    trait_basics();
    default_implementation();
    trait_as_parameter();
    trait_as_return();
    trait_objects();
    generic_trait();
    associated_types();
    supertrait_example();
    blanket_impl();
    standard_traits();
    manual_trait_impl();
    trait_with_generics();

    println!("\n================== Trait 总结 ==================");
    println!();
    println!("【Trait 定义】");
    println!("- trait TraitName {{ ... }}");
    println!("- impl TraitName for Type {{ ... }}");
    println!();
    println!("【默认实现】");
    println!("- trait 可以有默认方法实现");
    println!("- 可以覆盖默认实现");
    println!();
    println!("【Trait 作为参数】");
    println!("- impl Trait 语法糖");
    println!("- trait Bound: <T: Trait>");
    println!("- where 子句提高可读性");
    println!();
    println!("【Trait 作为返回值】");
    println!("- impl Trait 返回类型");
    println!("- 只允许返回单一具体类型");
    println!();
    println!("【Trait 对象】");
    println!("- dyn Trait 创建 trait 对象");
    println!("- 需要 Box 包装");
    println!("- 运行时动态分发");
    println!();
    println!("【常用标准库 Trait】");
    println!("- Debug, Clone, Copy");
    println!("- PartialEq, Eq, PartialOrd, Ord");
    println!("- Display, Default");
    println!("- From, Into, AsRef, AsMut");
    println!();
    println!("【最佳实践】");
    println!("- 小 trait 优于大 trait");
    println!("- 优先使用泛型而非 trait 对象");
    println!("- 为库提供具体错误类型");
    println!("- 实现标准 trait 使类型更实用");
}

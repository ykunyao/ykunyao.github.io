// =============================================================================
// Rust 学习示例 9: 错误处理
// =============================================================================
// Rust 以其独特的错误处理方式著称
// 它将错误分为两类：可恢复错误和不可恢复错误
// 本文件将详细介绍 Rust 的错误处理机制

// ============================================================================
// 错误类型概述
// ============================================================================
// Rust 的错误处理分为两大类：
// 1. 可恢复错误 (Recoverable) - 使用 Result<T, E>
// 2. 不可恢复错误 (Unrecoverable) - 使用 panic!

// ============================================================================
// 1. panic! 宏 - 不可恢复错误
// ============================================================================

fn panic_examples() {
    println!("================== panic! 不可恢复错误 ==================");

    // panic! 会终止程序并打印错误信息
    // 使用场景：
    // 1. 程序遇到无法继续的情况
    // 2. 违反了契约（如数组越界）
    // 3. 测试中断言失败

    // 简单 panic
    // panic!("这是一个 panic!");

    // 使用 assert! 系列宏
    let x = 10;
    assert!(x > 0, "x 应该大于 0");  // x > 0 为 true，不 panic
    assert_eq!(x, 10, "x 应该等于 10");
    assert_ne!(x, 0, "x 不应该等于 0");

    println!("断言通过: x = {}", x);

    // ============================================================================
    // 2. panic! 的输出信息
    // ============================================================================
    // 当 panic! 发生时，Rust 会：
    // 1. 打印错误消息
    // 2. 打印栈回溯（stack backtrace）
    // 3. 展开调用栈并清理数据（默认行为）

    // 可以设置 RUST_BACKTRACE=1 环境变量来获取详细回溯
    // 在 release 模式下，panic 会使用 abort 而不是 unwind

    // ============================================================================
    // 3. panic! vs unwrap
    // ============================================================================

    // Option 的 unwrap() - 如果是 None 则 panic
    let some_value: Option<i32> = Some(5);
    // let none_value: Option<i32> = None;
    // let _ = none_value.unwrap();  // panic!

    // Result 的 unwrap() - 如果是 Err 则 panic
    let ok_value: Result<i32, &str> = Ok(5);
    // let _ = ok_value.unwrap();  // Ok(5)，返回 5
    // let _ = Err::<i32, _>("error").unwrap();  // panic!

    println!("unwrap 示例完成");

    // ============================================================================
    // 4. 自定义 panic 行为
    // ============================================================================

    // 使用 abort 和 catch_unwind
    // std::panic::catch_unwind() 可以捕获 panic
    let result = std::panic::catch_unwind(|| {
        // println!("正常执行");
        "no panic"
    });

    match result {
        Ok(value) => println!("没有 panic: {}", value),
        Err(_) => println!("捕获到 panic!"),
    }
}

// ============================================================================
// 3. Result 枚举 - 可恢复错误
// ============================================================================

fn result_basics() {
    println!("\n================== Result 基础 ==================");

    // Result<T, E> 的定义
    // enum Result<T, E> {
    //     Ok(T),   // 成功，包含值
    //     Err(E),  // 失败，包含错误
    // }

    // 基本用法
    let ok: Result<i32, &str> = Ok(42);
    let err: Result<i32, &str> = Err("出错了");

    match ok {
        Ok(v) => println!("成功: {}", v),
        Err(e) => println!("失败: {}", e),
    }

    match err {
        Ok(v) => println!("成功: {}", v),
        Err(e) => println!("失败: {}", e),
    }

    // ============================================================================
    // 4. Result 的方法链
    // ============================================================================

    let numbers = vec![1, 2, 3, 4, 5];

    // parse() 返回 Result<usize, ParseIntError>
    let position = numbers.iter().position(|&x| x == 3);
    println!("找到 3 的位置: {:?}", position);

    // find() 返回 Option
    let number = numbers.iter().find(|&&x| x == 3);
    println!("找到 3: {:?}", number);
}

// ============================================================================
// 5. 传播错误
// ============================================================================

fn error_propagation() {
    println!("\n================== 错误传播 ==================");

    // 手动传播错误
    fn read_username_from_file_manual() -> Result<String, std::io::Error> {
        let file = std::fs::File::open("nonexistent.txt")?;  // 手动传播
        // 或者 let file = match ... { Ok(f) => f, Err(e) => return Err(e) };
        Ok(String::from("file opened"))
    }

    // 使用 ? 操作符（推荐）
    // ? 会自动将 Err 向上传播
    // fn read_username() -> Result<String, std::io::Error> {
    //     let mut file = std::fs::File::open("username.txt")?;
    //     let mut username = String::new();
    //     std::io::Read::read_to_string(&mut file, &mut username)?;
    //     Ok(username)
    // }

    println!("错误传播示例完成");
}

// ============================================================================
// 6. 自定义错误类型
// ============================================================================

use std::fmt;
use std::num::ParseIntError;

// 自定义错误类型
#[derive(Debug)]
enum MyError {
    ParseError(ParseIntError),
    InvalidInput(String),
    DivisionByZero,
}

impl fmt::Display for MyError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            MyError::ParseError(e) => write!(f, "解析错误: {}", e),
            MyError::InvalidInput(s) => write!(f, "无效输入: {}", s),
            MyError::DivisionByZero => write!(f, "除以零错误"),
        }
    }
}

// 实现 From trait 用于 ? 操作符自动转换
impl From<ParseIntError> for MyError {
    fn from(err: ParseIntError) -> Self {
        MyError::ParseError(err)
    }
}

impl std::error::Error for MyError {}

fn custom_error_examples() {
    println!("\n================== 自定义错误类型 ==================");

    fn parse_and_divide(a: &str, b: &str) -> Result<i32, MyError> {
        let a: i32 = a.parse()?;  // 自动转换为 MyError
        let b: i32 = b.parse()?;

        if b == 0 {
            return Err(MyError::DivisionByZero);
        }

        Ok(a / b)
    }

    // 测试各种错误情况
    match parse_and_divide("10", "2") {
        Ok(result) => println!("10 / 2 = {}", result),
        Err(e) => println!("错误: {}", e),
    }

    match parse_and_divide("10", "0") {
        Ok(result) => println!("{}", result),
        Err(e) => println!("捕获错误: {}", e),
    }

    match parse_and_divide("abc", "2") {
        Ok(result) => println!("{}", result),
        Err(e) => println!("捕获错误: {}", e),
    }
}

// ============================================================================
// 7. Option 与 Result 的转换
// ============================================================================

fn option_result_conversion() {
    println!("\n================== Option 与 Result 转换 ==================");

    // Option -> Result
    let some: Option<i32> = Some(5);
    let result: Result<i32, ()> = some.ok_or(());
    println!("Option -> Result: {:?}", result);

    let none: Option<i32> = None;
    let result = none.ok_or(());
    println!("None -> Result: {:?}", result);

    // Result -> Option
    let ok: Result<i32, &str> = Ok(5);
    let option: Option<i32> = ok.ok();
    println!("Result -> Option: {:?}", option);

    let err: Result<i32, &str> = Err("error");
    let option = err.ok();
    println!("Err -> Option: {:?}", option);

    // 使用 map_err 转换错误类型
    fn convert_error(r: Result<i32, &str>) -> Result<i32, String> {
        r.map_err(|e| e.to_string())
    }

    println!("错误转换: {:?}", convert_error(Ok(5)));
    println!("错误转换: {:?}", convert_error(Err("error")));
}

// ============================================================================
// 8. 实战：文件操作错误处理
// ============================================================================

fn file_operations() {
    println!("\n================== 文件操作错误处理 ==================");

    use std::fs;
    use std::io;

    fn read_file_contents(path: &str) -> io::Result<String> {
        // ? 操作符自动传播 io::Error
        let contents = fs::read_to_string(path)?;
        Ok(contents)
    }

    // 尝试读取不存在的文件
    match read_file_contents("nonexistent.txt") {
        Ok(contents) => println!("文件内容: {}", contents),
        Err(e) => println!("读取文件失败: {} (错误码: {})", e, e.kind()),
    }

    // 模式匹配不同类型的错误
    fn handle_io_error(e: io::Error) {
        match e.kind() {
            io::ErrorKind::NotFound => println!("文件未找到"),
            io::ErrorKind::PermissionDenied => println!("权限被拒绝"),
            io::ErrorKind::AlreadyExists => println!("文件已存在"),
            io::ErrorKind::WouldBlock => println!("操作会阻塞"),
            _ => println!("其他 IO 错误: {}", e),
        }
    }

    // 测试错误处理
    if let Err(e) = fs::write("test.txt", "Hello, Rust!") {
        handle_io_error(e);
    } else {
        println!("文件写入成功");

        // 读取文件
        match fs::read_to_string("test.txt") {
            Ok(contents) => println!("文件内容: {}", contents),
            Err(e) => println!("读取失败: {}", e),
        }

        // 删除文件
        if let Err(e) = fs::remove_file("test.txt") {
            println!("删除文件失败: {}", e);
        }
    }
}

// ============================================================================
// 9. 链式错误处理
// ============================================================================

fn chain_error_handling() {
    println!("\n================== 链式错误处理 ==================");

    use std::num::ParseIntError;

    // 使用 context 添加额外信息
    fn parse_and_add(a: &str, b: &str) -> Result<i32, ParseIntError> {
        let a: i32 = a.parse()?;
        let b: i32 = b.parse()?;
        Ok(a + b)
    }

    // 使用 map_err 转换错误信息
    fn parse_and_add_with_context(a: &str, b: &str) -> Result<i32, String> {
        parse_and_add(a, b).map_err(|e| {
            format!("无法解析 '{}' 和 '{}': {}", a, b, e)
        })
    }

    // 使用 and_then 进行链式操作
    fn parse_and_multiply(a: &str, b: &str) -> Result<i32, ParseIntError> {
        parse_and_add(a, b).and_then(|sum| {
            Ok(sum * 2)
        })
    }

    println!("基础加法: {:?}", parse_and_add("10", "20"));
    println!("带上下文: {:?}", parse_and_add_with_context("10", "abc"));
    println!("链式乘法: {:?}", parse_and_multiply("5", "3"));

    // 使用 unwrap_or_else 提供默认值
    let result = parse_and_add("abc", "10").unwrap_or(-1);
    println!("使用默认值: {}", result);
}

// ============================================================================
// 10. 多个错误类型的处理
// ============================================================================

fn multiple_error_types() {
    println!("\n================== 多个错误类型处理 ==================");

    use std::fmt::Display;

    // 方式1：使用泛型错误（需要 trait bound）
    fn print_result<T, E: Display>(result: Result<T, E>) {
        match result {
            Ok(value) => println!("成功: {:?}", value),
            Err(e) => println!("错误: {}", e),
        }
    }

    print_result(Ok::<_, &str>(42));
    print_result(Err::<i32, _>("出错了"));
    print_result(Ok::<_, ()>("hello"));

    // 方式2：使用 Box<dyn Error>
    fn generic_error() -> Result<(), Box<dyn std::error::Error>> {
        // 可以返回任何实现了 Error trait 的错误
        let _file = std::fs::File::open("test.txt")?;
        let _num = "42".parse::<i32>()?;
        Ok(())
    }

    match generic_error() {
        Ok(()) => println!("操作成功"),
        Err(e) => println!("错误: {}", e),
    }

    // 方式3：使用枚举组合多种错误
    #[derive(Debug)]
    enum AppError {
        IoError(std::io::Error),
        ParseError(std::num::ParseIntError),
        ValidationError(String),
    }

    impl From<std::io::Error> for AppError {
        fn from(e: std::io::Error) -> Self {
            AppError::IoError(e)
        }
    }

    impl From<std::num::ParseIntError> for AppError {
        fn from(e: std::num::ParseIntError) -> Self {
            AppError::ParseError(e)
        }
    }

    fn app_operation() -> Result<(), AppError> {
        let _file = std::fs::read_to_string("config.txt")?;
        let _num = "42".parse::<i32>()?;
        Ok(())
    }

    match app_operation() {
        Ok(()) => println!("应用操作成功"),
        Err(e) => {
            match e {
                AppError::IoError(e) => println!("IO 错误: {}", e),
                AppError::ParseError(e) => println!("解析错误: {}", e),
                AppError::ValidationError(msg) => println!("验证错误: {}", msg),
            }
        }
    }
}

// ============================================================================
// 11. 使用 anyhow 库（生产环境推荐）
// ============================================================================
// 在实际项目中，推荐使用 anyhow 库简化错误处理
// 这需要添加依赖到 Cargo.toml

// 下面是一个使用 anyhow 的示例（需要注释掉 Cargo.toml 的依赖）
/*
use anyhow::{Result, Context};

fn example_with_anyhow() -> Result<()> {
    let content = std::fs::read_to_string("config.txt")
        .context("无法读取配置文件")?;

    let num: i32 = content.trim().parse()
        .context("无法解析配置值")?;

    Ok(())
}
*/

// ============================================================================
// 12. 错误处理最佳实践
// ============================================================================

fn best_practices() {
    println!("\n================== 错误处理最佳实践 ==================");

    println!("1. 优先使用 Result 处理可恢复错误");
    println!("2. 使用 ? 操作符简化错误传播");
    println!("3. 为库提供具体的错误类型");
    println!("4. 为应用程序使用通用的错误类型");
    println!("5. 使用 context 添加额外信息");
    println!("6. 使用 unwrap_or, unwrap_or_else 提供合理的默认值");
    println!("7. 在测试中使用 unwrap/expect");
    println!("8. panic 只用于真正不可恢复的情况");
}

// ============================================================================
// 主函数
// ============================================================================

fn main() {
    panic_examples();
    result_basics();
    error_propagation();
    custom_error_examples();
    option_result_conversion();
    file_operations();
    chain_error_handling();
    multiple_error_types();
    best_practices();

    println!("\n================== 错误处理总结 ==================");
    println!();
    println!("【panic! - 不可恢复错误】");
    println!("- 程序遇到无法继续的情况时使用");
    println!("- 会终止程序并打印栈回溯");
    println!("- 使用场景：断言失败、数组越界等");
    println!();
    println!("【Result<T, E> - 可恢复错误】");
    println!("- Ok(T): 操作成功");
    println!("- Err(E): 操作失败");
    println!("- ? 操作符自动传播错误");
    println!();
    println!("【Option<T> - 值的存在性】");
    println!("- Some(T): 值存在");
    println!("- None: 值不存在");
    println!();
    println!("【最佳实践】");
    println!("1. 库函数返回 Result");
    println!("2. main 函数可以返回 Result<(), E>");
    println!("3. 使用 context() 添加错误上下文");
    println!("4. 优先使用具体错误类型");
    println!("5. 考虑使用 anyhow 简化应用开发");
}

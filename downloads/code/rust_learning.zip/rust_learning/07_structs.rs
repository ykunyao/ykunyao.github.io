// =============================================================================
// Rust 学习示例 7: 结构体 (Structs)
// =============================================================================
// 结构体是 Rust 中用于创建自定义数据类型的基本构建块
// 本文件将详细介绍结构体的定义、使用和方法

// ============================================================================
// 1. 结构体基础
// ============================================================================
// Rust 有三种结构体类型：
// 1. 命名结构体 (Named field struct)
// 2. 元组结构体 (Tuple struct)
// 3. 单元结构体 (Unit struct)

// ============================================================================
// 1.1 命名结构体
// ============================================================================

// 定义一个用户结构体
struct User {
    username: String,    // 用户名
    email: String,       // 邮箱
    sign_in_count: u64,  // 登录次数
    active: bool,        // 是否活跃
}

fn named_struct_examples() {
    println!("================== 命名结构体 ==================");

    // 创建结构体实例
    let user1 = User {
        email: String::from("user@example.com"),
        username: String::from("alice"),
        active: true,
        sign_in_count: 1,
    };

    println!("用户: {} ({})", user1.username, user1.email);
    println!("登录次数: {}, 活跃: {}", user1.sign_in_count, user1.active);

    // ============================================================================
    // 1.2 可变结构体实例
    // ============================================================================

    let mut user2 = User {
        email: String::from("another@example.com"),
        username: String::from("bob"),
        active: true,
        sign_in_count: 1,
    };

    // 修改字段（整个实例必须是可变的）
    user2.email = String::from("newemail@example.com");
    user2.sign_in_count += 1;

    println!("修改后的用户: {} ({})", user2.username, user2.email);

    // 注意：Rust 不允许部分可变，必须整个实例都可变
    // let mut user = User { ... };
    // user.username = String::from("...");  // 错误！
    // user.sign_in_count = 5;              // 错误！

    // ============================================================================
    // 1.3 字段初始化简写
    // ============================================================================
    // 当变量名与字段名相同时，可以省略重复的写法

    let email = String::from("test@example.com");
    let username = String::from("charlie");
    let sign_in_count = 5;
    let active = true;

    let user3 = User {
        email,           // 等价于 email: email
        username,        // 等价于 username: username
        sign_in_count,   // 等价于 sign_in_count: sign_in_count
        active,
    };

    println!("简写创建的用户: {}", user3.username);

    // ============================================================================
    // 1.4 结构体更新语法
    // ============================================================================
    // .. 语法允许从其他实例复制未指定的字段

    let user4 = User {
        email: String::from("fourth@example.com"),
        username: String::from("dave"),
        active: user1.active,
        sign_in_count: user1.sign_in_count,
    };

    // 等价于：
    let user4_alt = User {
        email: String::from("fourth@example.com"),
        username: String::from("dave"),
        ..user1  // 从 user1 复制其余字段
    };

    println!("更新的用户: {}", user4_alt.username);
}

// ============================================================================
// 2. 元组结构体
// ============================================================================
// 元组结构体类似元组，但有类型名
// 适合当你想要给元组起个名字，又不需要命名每个字段时

struct Color(i32, i32, i32);  // RGB 颜色
struct Point(i32, i32, i32);  // 3D 点

fn tuple_struct_examples() {
    println!("\n================== 元组结构体 ==================");

    let black = Color(0, 0, 0);
    let origin = Point(0, 0, 0);

    // 访问元组结构体的字段
    println!("黑色: R={}, G={}, B={}", black.0, black.1, black.2);
    println!("原点: ({}, {}, {})", origin.0, origin.1, origin.2);

    // 解构元组结构体
    let Color(r, g, b) = black;
    println!("解构颜色: r={}, g={}, b={}", r, g, b);

    // 元组结构体的相等性
    let c1 = Color(255, 0, 0);
    let c2 = Color(255, 0, 0);
    let c3 = Color(0, 255, 0);

    // 注意：元组结构体需要派生 Debug 或实现 PartialEq 来比较
    println!("c1 == c2: {}", c1.0 == c2.0 && c1.1 == c2.1 && c1.2 == c2.2);
    println!("c1 == c3: {}", c1.0 == c3.0 && c1.1 == c3.1 && c1.2 == c3.2);

    // 元组结构体作为函数参数
    fn distance(p1: Point, p2: Point) -> f64 {
        let dx = (p2.0 - p1.0) as f64;
        let dy = (p2.1 - p1.1) as f64;
        let dz = (p2.2 - p1.2) as f64;
        (dx * dx + dy * dy + dz * dz).sqrt()
    }

    let p1 = Point(1, 2, 3);
    let p2 = Point(4, 6, 10);
    println!("点间距离: {:.2}", distance(p1, p2));
}

// ============================================================================
// 3. 单元结构体
// ============================================================================
// 单元结构体是没有字段的结构体
// 主要用于实现 trait

struct AlwaysEqual;

fn unit_struct_examples() {
    println!("\n================== 单元结构体 ==================");

    let _always_equal = AlwaysEqual;
    // 单元结构体通常不存储数据，用于实现 trait

    println!("单元结构体创建成功");
}

// ============================================================================
// 4. 结构体与所有权
// ============================================================================

struct Owner {
    name: String,
    // id: i32,  // 如果是 Copy 类型，则不涉及所有权
}

fn ownership_in_structs() {
    println!("\n================== 结构体与所有权 ==================");

    // 结构体拥有其字段的所有权
    let owner = Owner {
        name: String::from("Alice"),  // String 移动到结构体中
    };

    println!("所有者: {}", owner.name);

    // 当结构体实例离开作用域时，字段也会被清理
    // 如果字段是 String，则会释放堆内存
}

// ============================================================================
// 5. 结构体方法
// ============================================================================
// 方法是绑定到结构体上的函数

struct Rectangle {
    width: u32,
    height: u32,
}

// impl 块：实现结构体的方法
impl Rectangle {
    // ============================================================================
    // 5.1 基本方法
    // ============================================================================

    // &self 是方法的第一个参数，表示对结构体实例的引用
    fn area(&self) -> u32 {
        self.width * self.height
    }

    fn width(&self) -> u32 {
        self.width
    }

    // ============================================================================
    // 5.2 可变方法
    // ============================================================================

    fn set_width(&mut self, width: u32) {
        self.width = width;
    }

    fn set_height(&mut self, height: u32) {
        self.height = height;
    }

    // ============================================================================
    // 5.3 构造函数（关联函数）
    // ============================================================================
    // 不以 self 为参数的函数叫做"关联函数"
    // 通常用作构造函数

    fn new(width: u32, height: u32) -> Rectangle {
        Rectangle { width, height }
    }

    fn square(size: u32) -> Rectangle {
        Rectangle { width: size, height: size }
    }

    // ============================================================================
    // 5.4 其他实用方法
    // ============================================================================

    fn can_hold(&self, other: &Rectangle) -> bool {
        self.width > other.width && self.height > other.height
    }

    fn rotate(&mut self) {
        // 交换宽高
        let temp = self.width;
        self.width = self.height;
        self.height = temp;
    }

    fn debug(&self) {
        println!("Rectangle {{ width: {}, height: {} }}", self.width, self.height);
    }
}

fn method_examples() {
    println!("\n================== 结构体方法 ==================");

    // 使用构造函数创建实例
    let rect = Rectangle::new(30, 50);
    println!("矩形尺寸: {} x {}", rect.width, rect.height);
    println!("面积: {}", rect.area());

    // 创建正方形
    let square = Rectangle::square(20);
    println!("正方形尺寸: {} x {}", square.width, square.height);

    // 调用方法
    let width = rect.width();
    println!("宽度方法: {}", width);

    // 测试 can_hold
    println!("rect 能容纳 square: {}", rect.can_hold(&square));
    println!("square 能容纳 rect: {}", square.can_hold(&rect));

    // 使用可变方法修改
    let mut mutable_rect = Rectangle::new(10, 20);
    println!("修改前: {:?}", (mutable_rect.width, mutable_rect.height));

    mutable_rect.set_width(40);
    mutable_rect.set_height(30);
    println!("修改后: {:?}", (mutable_rect.width, mutable_rect.height));

    // 旋转
    mutable_rect.rotate();
    println!("旋转后: {:?}", (mutable_rect.width, mutable_rect.height));

    // 调试方法
    rect.debug();
}

// ============================================================================
// 6. 多个 impl 块
// ============================================================================

impl Rectangle {
    fn perim(&self) -> u32 {
        2 * (self.width + self.height)
    }
}

// 也可以为其他类型实现方法
impl String {
    fn new_rectangle(&self) -> Option<Rectangle> {
        // 解析字符串 "widthxheight"
        let parts: Vec<&str> = self.split('x').collect();
        if parts.len() == 2 {
            let w: u32 = parts[0].parse().ok()?;
            let h: u32 = parts[1].parse().ok()?;
            Some(Rectangle::new(w, h))
        } else {
            None
        }
    }
}

fn multiple_impl_blocks() {
    println!("\n================== 多个 impl 块 ==================");

    let rect = Rectangle::new(30, 50);
    println!("周长: {}", rect.perim());

    let rect_str = "100x50";
    if let Some(rect) = rect_str.new_rectangle() {
        println!("从字符串创建矩形: {} x {} = {}", rect.width, rect.height, rect.area());
    }
}

// ============================================================================
// 7. 结构体与模式匹配
// ============================================================================

struct Circle {
    x: f64,
    y: f64,
    radius: f64,
}

struct Triangle {
    points: [(f64, f64); 3],
}

enum Shape {
    Circle(Circle),
    Rectangle(Rectangle),
    Triangle(Triangle),
}

fn struct_pattern_matching() {
    println!("\n================== 结构体与模式匹配 ==================");

    let shapes = vec![
        Shape::Circle(Circle { x: 0.0, y: 0.0, radius: 10.0 }),
        Shape::Rectangle(Rectangle::new(30, 50)),
        Shape::Triangle(Triangle {
            points: [(0.0, 0.0), (3.0, 0.0), (1.5, 3.0)],
        }),
    ];

    for shape in &shapes {
        match shape {
            Shape::Circle(c) => {
                let area = std::f64::consts::PI * c.radius * c.radius;
                println!("圆形: 面积 = {:.2}", area);
            }
            Shape::Rectangle(r) => {
                println!("矩形: 面积 = {}", r.area());
            }
            Shape::Triangle(t) => {
                println!("三角形: {:?}", t.points);
            }
        }
    }

    // 解构结构体字段
    let Circle { x, y, radius } = Circle { x: 5.0, y: 5.0, radius: 10.0 };
    println!("解构圆形: x={}, y={}, radius={}", x, y, radius);
}

// ============================================================================
// 8. 结构体派生 trait
// ============================================================================

#[derive(Debug, Clone, Copy, PartialEq)]  // 派生 trait
struct Point2D {
    x: i32,
    y: i32,
}

impl Point2D {
    fn new(x: i32, y: i32) -> Self {
        Point2D { x, y }
    }

    fn origin() -> Self {
        Point2D { x: 0, y: 0 }
    }
}

fn derived_traits() {
    println!("\n================== 结构体派生 trait ==================");

    let p1 = Point2D::new(10, 20);
    let p2 = Point2D::new(10, 20);
    let p3 = Point2D::origin();

    // Debug trait：打印调试信息
    println!("p1: {:?}", p1);
    println!("p3: {:?}", p3);

    // Clone trait：克隆
    let p4 = p1.clone();
    println!("p4 (克隆): {:?}", p4);

    // Copy trait：自动复制
    let p5 = p1;  // Copy，不是 Move
    println!("p1 (Copy 后): {:?}", p1);
    println!("p5: {:?}", p5);

    // PartialEq trait：比较相等
    println!("p1 == p2: {}", p1 == p2);
    println!("p1 == p3: {}", p1 == p3);
}

// ============================================================================
// 9. 结构体内存布局
// ============================================================================

#[repr(C)]
struct PackedStruct {
    a: u8,   // 1 byte
    b: u32,  // 4 bytes
    c: u8,   // 1 byte
}

fn memory_layout() {
    println!("\n================== 结构体内存布局 ==================");

    // 标准布局
    let normal = Rectangle { width: 10, height: 20 };
    println!("Rectangle 大小: {} bytes", std::mem::size_of::<Rectangle>());
    println!("(u32 + u32 = {} bytes)", std::mem::size_of::<u32>() * 2);

    // 紧凑结构体
    let packed = PackedStruct { a: 1, b: 2, c: 3 };
    println!("PackedStruct 大小: {} bytes", std::mem::size_of::<PackedStruct>());

    // 对齐
    println!("\n对齐说明:");
    println!("Rectangle 对齐: {} bytes", std::mem::align_of::<Rectangle>());
    println!("PackedStruct 对齐: {} bytes", std::mem::align_of::<PackedStruct>());
}

// ============================================================================
// 主函数
// ============================================================================

fn main() {
    named_struct_examples();
    tuple_struct_examples();
    unit_struct_examples();
    ownership_in_structs();
    method_examples();
    multiple_impl_blocks();
    struct_pattern_matching();
    derived_traits();
    memory_layout();

    println!("\n================== 结构体总结 ==================");
    println!();
    println!("【三种结构体类型】");
    println!("1. 命名结构体: struct Name {{ field: Type }}");
    println!("2. 元组结构体: struct Name(Type1, Type2)");
    println!("3. 单元结构体: struct Name");
    println!();
    println!("【方法定义】");
    println!("- 使用 impl 块定义");
    println!("- &self 参数表示不可变借用");
    println!("- &mut self 参数表示可变借用");
    println!("- 关联函数: 不以 self 为参数的函数（常用作构造函数）");
    println!();
    println!("【常用派生 trait】");
    println!("- Debug: {:?} 格式化输出");
    println!("- Clone: .clone() 深拷贝");
    println!("- Copy: 按位复制");
    println!("- PartialEq: == 和 != 比较");
    println!();
    println!("【最佳实践】");
    println!("- 字段使用有意义的命名");
    println!("- 提供构造函数（如 new()）作为创建实例的标准方式");
    println!("- 派生 Debug trait 以便调试");
}

// =============================================================================
// Rust 学习示例 13: 集合类型 (Collections)
// =============================================================================
// Rust 标准库提供了多种强大的集合类型
// 本文件将详细介绍 Vec, HashMap, HashSet 等常用集合

// ============================================================================
// 1. Vec (动态数组)
// ============================================================================

fn vec_examples() {
    println!("================== Vec 动态数组 ==================");

    // 创建 Vec
    let mut v: Vec<i32> = Vec::new();
    v.push(1);
    v.push(2);
    v.push(3);
    println!("Vec::new: {:?}", v);

    // 使用 vec! 宏
    let v = vec![1, 2, 3, 4, 5];
    println!("vec! 宏: {:?}", v);

    // 从数组创建
    let arr = [1, 2, 3, 4, 5];
    let v: Vec<i32> = arr.into();
    println!("从数组创建: {:?}", v);

    // ============================================================================
    // 2. 读取元素
    // ============================================================================

    let v = vec![1, 2, 3, 4, 5];

    // 索引访问（会 panic）
    let third = v[2];
    println!("第三个元素: {}", third);

    // get 方法（返回 Option）
    match v.get(2) {
        Some(value) => println!("第三个元素: {}", value),
        None => println!("索引超出范围"),
    }

    // 安全访问：检查范围
    let index = 10;
    match v.get(index) {
        Some(value) => println!("v[{}] = {}", index, value),
        None => println!("v[{}] 不存在", index),
    }

    // ============================================================================
    // 3. 遍历
    // ============================================================================

    let v = vec![1, 2, 3, 4, 5];

    // 不可变遍历
    for i in &v {
        print!("{} ", i);
    }
    println!();

    // 可变遍历
    let mut v = vec![1, 2, 3];
    for i in &mut v {
        *i *= 2;
    }
    println!("乘以2: {:?}", v);

    // 枚举遍历
    for (index, value) in v.iter().enumerate() {
        println!("[{}] = {}", index, value);
    }

    // ============================================================================
    // 4. 修改 Vec
    // ============================================================================

    let mut v = vec![1, 2, 3];

    // push 添加元素
    v.push(4);
    v.push(5);
    println!("push: {:?}", v);

    // pop 删除并返回最后一个元素
    let last = v.pop();
    println!("pop: {:?}, 剩余: {:?}", last, v);

    // insert 在指定位置插入
    v.insert(0, 0);
    println!("insert: {:?}", v);

    // remove 删除并返回指定位置的元素
    let removed = v.remove(2);
    println!("remove: {:?}, 剩余: {:?}", removed, v);

    // clear 清空
    let mut v = vec![1, 2, 3];
    v.clear();
    println!("clear: {:?}", v);

    // ============================================================================
    // 5. Vec 其他方法
    // ============================================================================

    let v = vec![1, 2, 3, 4, 5];

    // len 和 is_empty
    println!("len: {}", v.len());
    println!("is_empty: {}", v.is_empty());

    // contains
    println!("contains 3: {}", v.contains(&3));
    println!("contains 10: {}", v.contains(&10));

    // first 和 last
    println!("first: {:?}", v.first());
    println!("last: {:?}", v.last());

    // 切片
    println!("slice [1..3]: {:?}", &v[1..3]);

    // extend 扩展
    let mut v = vec![1, 2, 3];
    v.extend([4, 5, 6]);
    println!("extend: {:?}", v);

    // append 追加
    let mut v1 = vec![1, 2];
    let mut v2 = vec![3, 4];
    v1.append(&mut v2);
    println!("append: {:?}", v1);
    println!("v2 现在为空: {:?}", v2);

    // ============================================================================
    // 6. Vec 排序
    // ============================================================================

    let mut v = vec![3, 1, 4, 1, 5, 9, 2, 6];
    v.sort();
    println!("sort: {:?}", v);

    let mut v = vec![3.0, 1.0, 4.0];
    v.sort_by(|a, b| a.partial_cmp(b).unwrap());
    println!("sort_by: {:?}", v);

    // 唯一化
    let mut v = vec![1, 2, 2, 3, 3, 3, 4];
    v.dedup();
    println!("dedup: {:?}", v);

    // 反转
    v.reverse();
    println!("reverse: {:?}", v);
}

// ============================================================================
// 2. String (字符串)
// ============================================================================

fn string_examples() {
    println!("\n================== String 字符串 ==================");

    // 创建 String
    let s = String::new();
    let s = String::from("hello");
    let s = "hello".to_string();
    println!("创建 String: {}", s);

    // 从字符串字面量
    let s: String = "world".into();
    println!("into: {}", s);

    // ============================================================================
    // 3. 字符串操作
    // ============================================================================

    let mut s = String::from("hello");

    // push 添加字符
    s.push(' ');
    println!("push: {}", s);

    // push_str 添加字符串
    s.push_str("world");
    println!("push_str: {}", s);

    // + 操作符（会获取所有权）
    let s1 = String::from("Hello, ");
    let s2 = String::from("world!");
    let s3 = s1 + &s2;  // s1 被移动，不能再使用
    println!("+: {}", s3);

    // format! 宏
    let s1 = String::from("tic");
    let s2 = String::from("tac");
    let s3 = String::from("toe");
    let s = format!("{}-{}-{}", s1, s2, s3);
    println!("format!: {}", s);

    // ============================================================================
    // 4. 字符串索引和切片
    // ============================================================================

    let s = "hello world";

    // 切片（小心字节边界）
    let hello = &s[0..5];
    let world = &s[6..11];
    println!("切片: {}, {}", hello, world);

    // 遍历字符
    for c in "नमस्ते".chars() {
        print!("{} ", c);
    }
    println!();

    // 遍历字节
    for b in "hello".bytes() {
        print!("{} ", b);
    }
    println!();

    // 遍历字形簇（需要 unicode-segmentation crate）
    println!("len (字节): {}", s.len());
    println!("chars count: {}", s.chars().count());

    // ============================================================================
    // 5. 字符串方法
    // ============================================================================

    let s = "  hello world  ";

    // trim
    println!("trim: '{}'", s.trim());

    // to_uppercase / to_lowercase
    println!("upper: {}", "hello".to_uppercase());
    println!("lower: {}", "HELLO".to_lowercase());

    // replace
    println!("replace: {}", "hello world".replace("world", "rust"));

    // split
    let words: Vec<&str> = "hello world rust".split(' ').collect();
    println!("split: {:?}", words);

    // contains 和 starts_with
    println!("contains 'world': {}", "hello world".contains("world"));
    println!("starts_with 'hello': {}", "hello world".starts_with("hello"));

    // is_empty
    println!("is_empty: {}", String::new().is_empty());

    // parse 转换类型
    let num: i32 = "42".parse().unwrap();
    println!("parse: {}", num);
}

// ============================================================================
// 3. HashMap
// ============================================================================

fn hashmap_examples() {
    println!("\n================== HashMap ==================");

    use std::collections::HashMap;

    // 创建 HashMap
    let mut map: HashMap<&str, i32> = HashMap::new();
    map.insert("apple", 3);
    map.insert("banana", 5);
    println!("HashMap::new: {:?}", map);

    // from 数组
    let scores: HashMap<&str, i32> = [
        ("blue", 10),
        ("yellow", 50),
    ].into();
    println!("from 数组: {:?}", scores);

    // ============================================================================
    // 4. 访问元素
    // ============================================================================

    let mut map = HashMap::new();
    map.insert("apple", 3);

    // get 返回 Option
    match map.get("apple") {
        Some(value) => println!("apple: {}", value),
        None => println!("不存在"),
    }

    // get 配合 unwrap_or
    let value = map.get("banana").copied().unwrap_or(0);
    println!("banana (默认值0): {}", value);

    // contains_key
    println!("contains 'apple': {}", map.contains_key("apple"));

    // ============================================================================
    // 5. 修改 HashMap
    // ============================================================================

    let mut map = HashMap::new();

    // insert
    map.insert("red", 10);
    println!("insert: {:?}", map);

    // 更新值
    let old = map.insert("red", 20);
    println!("更新返回值: {:?}, map: {:?}", old, map);

    // entry 和 or_insert
    let text = "hello world wonderful world";
    let mut word_count = HashMap::new();

    for word in text.split_whitespace() {
        let count = word_count.entry(word).or_insert(0);
        *count += 1;
    }
    println!("词频: {:?}", word_count);

    // remove
    let removed = map.remove("red");
    println!("remove: {:?}, 剩余: {:?}", removed, map);

    // ============================================================================
    // 6. 遍历 HashMap
    // ============================================================================

    let scores = vec![
        ("blue", 10),
        ("yellow", 50),
        ("red", 30),
    ];
    let map: HashMap<_, _> = scores.into_iter().collect();

    // 遍历键值对
    for (key, value) in &map {
        println!("{}: {}", key, value);
    }

    // 只遍历键
    for key in map.keys() {
        print!("{} ", key);
    }
    println!();

    // 只遍历值
    for value in map.values() {
        print!("{} ", value);
    }
    println!();

    // ============================================================================
    // 7. HashMap 其他方法
    // ============================================================================

    let mut map = HashMap::new();
    map.insert("a", 1);
    map.insert("b", 2);

    println!("len: {}", map.len());
    println!("is_empty: {}", map.is_empty());

    // 克隆
    let map2 = map.clone();
    println!("clone: {:?}", map2);

    // 清空
    map.clear();
    println!("clear: {:?}", map);
}

// ============================================================================
// 4. HashSet
// ============================================================================

fn hashset_examples() {
    println!("\n================== HashSet ==================");

    use std::collections::HashSet;

    // 创建 HashSet
    let mut set: HashSet<i32> = HashSet::new();
    set.insert(1);
    set.insert(2);
    set.insert(3);
    println!("HashSet::new: {:?}", set);

    // 从 Vec 创建
    let set: HashSet<i32> = vec![1, 2, 3, 2, 1].into_iter().collect();
    println!("从 Vec 创建: {:?}", set);

    // ============================================================================
    // 5. HashSet 操作
    // ============================================================================

    let a = vec![1, 2, 3, 4];
    let b = vec![3, 4, 5, 6];

    let set_a: HashSet<_> = a.into_iter().collect();
    let set_b: HashSet<_> = b.into_iter().collect();

    // 并集
    let union: HashSet<_> = set_a.union(&set_b).collect();
    println!("并集: {:?}", union);

    // 交集
    let intersection: HashSet<_> = set_a.intersection(&set_b).collect();
    println!("交集: {:?}", intersection);

    // 差集 (A - B)
    let difference: HashSet<_> = set_a.difference(&set_b).collect();
    println!("差集: {:?}", difference);

    // 对称差集 (A Δ B)
    let sym_diff: HashSet<_> = set_a.symmetric_difference(&set_b).collect();
    println!("对称差集: {:?}", sym_diff);

    // 子集和超集
    let sub = [1, 2].iter().collect::<HashSet<_>>();
    let sup = [1, 2, 3].iter().collect::<HashSet<_>>();
    println!("sub 是 sup 的子集: {}", sub.is_subset(&sup));
    println!("sup 是 sub 的超集: {}", sup.is_superset(&sub));
}

// ============================================================================
// 6. VecDeque (双端队列)
// ============================================================================

fn vecdeque_examples() {
    println!("\n================== VecDeque ==================");

    use std::collections::VecDeque;

    let mut deque: VecDeque<i32> = VecDeque::new();
    deque.push_back(1);
    deque.push_back(2);
    deque.push_front(0);
    println!("push: {:?}", deque);

    // 从两端 pop
    let front = deque.pop_front();
    let back = deque.pop_back();
    println!("pop: front={:?}, back={:?}, 剩余: {:?}", front, back, deque);

    // 查看
    println!("front: {:?}", deque.front());
    println!("back: {:?}", deque.back());

    // Vec 转换为 VecDeque
    let vec = vec![1, 2, 3];
    let deque: VecDeque<_> = vec.into();
    println!("从 Vec: {:?}", deque);
}

// ============================================================================
// 7. BinaryHeap (二叉堆)
// ============================================================================

fn binaryheap_examples() {
    println!("\n================== BinaryHeap ==================");

    use std::collections::BinaryHeap;

    let mut heap = BinaryHeap::new();
    heap.push(3);
    heap.push(1);
    heap.push(5);
    heap.push(2);
    println!("push: {:?}", heap);

    // peek 查看最大元素
    println!("peek: {:?}", heap.peek());

    // pop 弹出最大元素
    while let Some(v) = heap.pop() {
        print!("{} ", v);
    }
    println!();

    // 最大堆排序
    let mut heap = BinaryHeap::from([3, 1, 4, 1, 5, 9, 2, 6]);
    println!("最大堆: {:?}", heap);
    let sorted: Vec<_> = heap.into_sorted_vec();
    println!("排序后: {:?}", sorted);
}

// ============================================================================
// 8. BTreeMap 和 BTreeSet
// ============================================================================

fn btree_examples() {
    println!("\n================== BTreeMap 和 BTreeSet ==================");

    use std::collections::{BTreeMap, BTreeSet};

    // BTreeMap - 有序键值对
    let mut bmap = BTreeMap::new();
    bmap.insert("b", 2);
    bmap.insert("a", 1);
    bmap.insert("c", 3);
    println!("BTreeMap: {:?}", bmap);

    // BTreeSet - 有序集合
    let mut bset = BTreeSet::new();
    bset.insert(3);
    bset.insert(1);
    bset.insert(2);
    println!("BTreeSet: {:?}", bset);

    // 有序遍历
    println!("有序遍历:");
    for (k, v) in &bmap {
        print!("{}:{} ", k, v);
    }
    println!();

    // 范围查询
    println!("范围 'a'..'c': {:?}", bmap.range("a".."c").collect::<Vec<_>>());
}

// ============================================================================
// 9. 迭代器适配器
// ============================================================================

fn iterator_adaptors() {
    println!("\n================== 迭代器适配器 ==================");

    let numbers = vec![1, 2, 3, 4, 5];

    // map - 转换
    let doubled: Vec<_> = numbers.iter().map(|x| x * 2).collect();
    println!("map: {:?}", doubled);

    // filter - 过滤
    let evens: Vec<_> = numbers.iter().filter(|x| *x % 2 == 0).collect();
    println!("filter (偶数): {:?}", evens);

    // filter_map - 过滤和转换
    let strings = vec!["1", "two", "3", "four"];
    let numbers: Vec<_> = strings.iter().filter_map(|s| s.parse().ok()).collect();
    println!("filter_map: {:?}", numbers);

    // take 和 skip
    let v: Vec<_> = (1..=10).collect();
    println!("take(3): {:?}", &v[..3]);
    println!("skip(5): {:?}", &v[5..]);

    // take_while 和 skip_while
    let result: Vec<_> = (1..=10).take_while(|x| *x < 5).collect();
    println!("take_while(<5): {:?}", result);

    // enumerate
    let indexed: Vec<_> = ["a", "b", "c"].iter().enumerate().collect();
    println!("enumerate: {:?}", indexed);

    // zip
    let zipped: Vec<_> = [1, 2, 3].iter().zip(['a', 'b', 'c'].iter()).collect();
    println!("zip: {:?}", zipped);

    // flatten
    let nested = vec![vec![1, 2], vec![3, 4], vec![5]];
    let flat: Vec<_> = nested.into_iter().flatten().collect();
    println!("flatten: {:?}", flat);

    // chain
    let chained: Vec<_> = [1, 2].iter().chain([3, 4].iter()).collect();
    println!("chain: {:?}", chained);
}

// ============================================================================
// 10. 消费者方法
// ============================================================================

fn consumer_methods() {
    println!("\n================== 消费者方法 ==================");

    let numbers = vec![1, 2, 3, 4, 5];

    // collect - 收集到容器
    let set: std::collections::HashSet<_> = numbers.iter().cloned().collect();
    println!("collect -> HashSet: {:?}", set);

    // fold - 折叠
    let sum = numbers.iter().fold(0, |acc, x| acc + x);
    println!("fold sum: {}", sum);
    let product = numbers.iter().fold(1, |acc, x| acc * x);
    println!("fold product: {}", product);

    // reduce
    let max = numbers.iter().copied().reduce(|a, b| a.max(b));
    println!("reduce max: {:?}", max);

    // sum 和 product
    println!("sum: {}", numbers.iter().sum::<i32>());
    println!("product: {}", numbers.iter().product::<i32>());

    // find 和 position
    let result = numbers.iter().find(|&&x| x > 3);
    println!("find >3: {:?}", result);
    let pos = numbers.iter().position(|&x| x == 3);
    println!("position of 3: {:?}", pos);

    // any 和 all
    println!("any > 3: {}", numbers.iter().any(|&x| x > 3));
    println!("all > 0: {}", numbers.iter().all(|&x| x > 0));

    // count
    println!("count even: {}", numbers.iter().filter(|&&x| x % 2 == 0).count());

    // max 和 min
    println!("max: {:?}", numbers.iter().max());
    println!("min: {:?}", numbers.iter().min());
}

// ============================================================================
// 主函数
// ============================================================================

fn main() {
    vec_examples();
    string_examples();
    hashmap_examples();
    hashset_examples();
    vecdeque_examples();
    binaryheap_examples();
    btree_examples();
    iterator_adaptors();
    consumer_methods();

    println!("\n================== 集合类型总结 ==================");
    println!();
    println!("【Vec<T> - 动态数组】");
    println!("- push/pop 添加删除");
    println!("- get 安全的索引访问");
    println!("- 常用方法: len, is_empty, clear, extend");
    println!();
    println!("【String - 字符串】");
    println!("- push, push_str, + 操作符");
    println!("- chars, bytes, split 遍历");
    println!("- trim, replace, to_uppercase");
    println!();
    println!("【HashMap<K, V> - 哈希表】");
    println!("- insert, get, entry");
    println!("- or_insert 更新默认值");
    println!();
    println!("【HashSet<T> - 哈希集合】");
    println!("- union, intersection, difference");
    println!("- is_subset, is_superset");
    println!();
    println!("【其他集合】");
    println!("- VecDeque: 双端队列");
    println!("- BinaryHeap: 最大堆");
    println!("- BTreeMap/Set: 有序键值对/集合");
}

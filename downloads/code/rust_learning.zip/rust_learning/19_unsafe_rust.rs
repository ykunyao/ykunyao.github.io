// =============================================================================
// Rust 学习示例 19: Unsafe Rust
// =============================================================================
// Rust 的 unsafe 超能力允许绕过编译器的一些安全检查
// 本文件将详细介绍 unsafe 的使用场景和注意事项

// ============================================================================
// 1. Unsafe 的五个超能力
// ============================================================================

// Rust 的 unsafe 代码块提供以下五个额外能力：
// 1. 解引用原始指针 (raw pointers)
// 2. 调用 unsafe 函数或方法
// 3. 访问或修改可变静态变量
// 4. 实现 unsafe trait
// 5. 访问 union 的字段

fn five_powers() {
    println!("================== Unsafe 五项超能力 ==================");

    // ============================================================================
    // 1. 解引用原始指针
    // ============================================================================

    // 创建原始指针（可以是不可变的或可变的）
    let mut num = 5;
    let r1 = &num as *const i32;      // 不可变原始指针
    let r2 = &mut num as *mut i32;    // 可变原始指针

    unsafe {
        // 解引用原始指针
        println!("r1 指向: {}", *r1);
        println!("r2 指向: {}", *r2);

        // 修改通过可变原始指针
        *r2 = 10;
        println!("修改后 num: {}", num);
    }

    // ============================================================================
    // 2. 调用 unsafe 函数
    // ============================================================================

    // 声明 unsafe 函数
    unsafe fn dangerous_function() {
        println!("这是 unsafe 函数");
    }

    // 调用需要 unsafe 块
    unsafe {
        dangerous_function();
    }

    // ============================================================================
    // 3. 访问可变静态变量
    // ============================================================================

    static mut COUNTER: i32 = 0;

    unsafe {
        COUNTER += 1;
        println!("COUNTER: {}", COUNTER);
    }

    // ============================================================================
    // 4. 实现 unsafe trait
    // ============================================================================

    unsafe trait UnsafeTrait {
        fn method(&self);
    }

    struct MyStruct;

    unsafe impl UnsafeTrait for MyStruct {
        fn method(&self) {
            println!("实现 unsafe trait");
        }
    }

    let s = MyStruct;
    s.method();

    // ============================================================================
    // 5. 访问 union
    // ============================================================================

    union IntOrFloat {
        as_int: i32,
        as_float: f32,
    }

    let mut value = IntOrFloat { as_int: 42 };
    unsafe {
        println!("as_int: {}", value.as_int);
        value.as_float = 3.14;
        println!("as_float: {}", value.as_float);
    }
}

// ============================================================================
// 2. 原始指针
// ============================================================================

fn raw_pointers() {
    println!("\n================== 原始指针 ==================");

    // 从引用创建原始指针
    let num = 10;
    let r1 = &num as *const i32;  // 不可变原始指针
    let mut num2 = 20;
    let r2 = &mut num2 as *mut i32;  // 可变原始指针

    println!("r1: {:?}", r1);
    println!("r2: {:?}", r2);

    // 从原始指针创建引用（需要 unsafe）
    unsafe {
        println!("从原始指针读取: {}", *r1);
        *r2 = 30;
        println!("通过原始指针修改: {}", num2);
    }

    // ============================================================================
    // 2. 原始指针的特点
    // ============================================================================

    // 1. 可以有多个可变指针指向同一位置
    let mut num = 100;
    let r1 = &mut num as *mut i32;
    let r2 = &mut num as *mut i32;

    unsafe {
        *r1 = 200;
        *r2 = 300;
        println!("num 最终值: {}", num);
    }

    // 2. 不保证指向有效内存
    let dangling = 42 as *const i32;
    unsafe {
        // println!("{}", *dangling);  // 未定义行为！
    }

    // 3. 可以是 null
    let null_ptr: *const i32 = std::ptr::null();
    println!("null_ptr 是 null: {}", null_ptr.is_null());
}

// ============================================================================
// 3. 外部函数接口 (FFI)
// ============================================================================

fn ffi_examples() {
    println!("\n================== FFI 外部函数接口 ==================");

    // 声明外部函数
    // extern "C" {
    //     fn abs(input: i32) -> i32;
    // }

    // 安全包装器
    // fn safe_abs(input: i32) -> i32 {
    //     unsafe {
    //         abs(input)
    //     }
    // }

    // 使用 #[repr(C)] 确保内存布局
    #[repr(C)]
    struct Point {
        x: f32,
        y: f32,
    }

    let point = Point { x: 1.0, y: 2.0 };
    println!("C 结构体: ({}, {})", point.x, point.y);

    // 回调函数
    type Callback = extern "C" fn(i32) -> i32;

    extern "C" {
        fn call_with_five(cb: Callback) -> i32;
    }

    extern "C" fn double(x: i32) -> i32 {
        x * 2
    }

    unsafe {
        // let result = call_with_five(double);
        // println!("回调结果: {}", result);
        println!("FFI 示例（需要实际 C 库）");
    }
}

// ============================================================================
// 4. 手动内存管理
// ============================================================================

fn manual_memory() {
    println!("\n================== 手动内存管理 ==================");

    // Box::into_raw 转换为原始指针
    let mut boxed = Box::new(5);
    let raw = Box::into_raw(boxed) as *mut i32;

    println!("原始指针: {:?}", raw);

    unsafe {
        // 解引用并修改
        *raw = 10;
        println!("通过原始指针修改: {}", *raw);

        // 转换回 Box
        let boxed = Box::from_raw(raw);
        println!("转回 Box: {}", boxed);
    }

    // ============================================================================
    // 2. 分配和释放内存
    // ============================================================================

    unsafe {
        // 使用全局分配器
        use std::alloc::{alloc, dealloc, Layout};

        let layout = Layout::new::<i32>();
        let ptr = alloc(layout) as *mut i32;

        // 写入值
        ptr.write(42);
        println!("分配的内存: {}", ptr.read());

        // 释放内存
        dealloc(ptr as *mut u8, layout);
    }

    // ============================================================================
    // 3. 使用 Vec 的原始部件
    // ============================================================================

    let mut vec = vec![1, 2, 3, 4, 5];
    let (ptr, len, cap) = vec.as_ptr().as_ptr().to_raw_parts();
    println!("Vec 部件: ptr={:?}, len={}, cap={}", ptr, len, cap);

    // 从原始部件重建 Vec
    let rebuilt = unsafe {
        Vec::from_raw_parts(ptr, len, cap)
    };
    println!("重建的 Vec: {:?}", rebuilt);
}

// ============================================================================
// 5. 可变静态变量
// ============================================================================

fn static_variables() {
    println!("\n================== 可变静态变量 ==================");

    // 全局计数器（需要 unsafe 访问）
    static mut COUNTER: i32 = 0;

    unsafe {
        COUNTER += 1;
        println!("Counter: {}", COUNTER);
    }

    // ============================================================================
    // 2. 使用 Mutex 包装
    // ============================================================================

    use std::sync::Mutex;

    static GLOBAL_DATA: Mutex<i32> = Mutex::new(0);

    {
        let mut data = GLOBAL_DATA.lock().unwrap();
        *data += 100;
        println!("GLOBAL_DATA: {}", *data);
    }

    // ============================================================================
    // 3. 原子操作
    // ============================================================================

    use std::sync::atomic::{AtomicI32, Ordering};

    static COUNTER_ATOMIC: AtomicI32 = AtomicI32::new(0);

    COUNTER_ATOMIC.fetch_add(1, Ordering::SeqCst);
    COUNTER_ATOMIC.fetch_add(1, Ordering::SeqCst);
    COUNTER_ATOMIC.fetch_add(1, Ordering::SeqCst);

    println!("原子计数器: {}", COUNTER_ATOMIC.load(Ordering::SeqCst));
}

// ============================================================================
// 6. Unsafe Trait
// ============================================================================

fn unsafe_trait_examples() {
    println!("\n================== Unsafe Trait ==================");

    // Sync 和 Send 是 unsafe trait
    // 编译器自动为大多数类型实现

    // 手动实现 unsafe trait
    unsafe trait MayAlias {
        fn get(&self) -> i32;
    }

    struct Wrapper {
        value: i32,
    }

    unsafe impl MayAlias for Wrapper {
        fn get(&self) -> i32 {
            self.value
        }
    }

    let w = Wrapper { value: 42 };
    println!("MayAlias 实现: {}", w.get());

    // ============================================================================
    // 2. !Sync 和 !Send 类型
    // ============================================================================

    // 使用 #[derive(Default)] 需要 T: Default
    // Rc<T> 不是 Send（因为引用计数）

    use std::rc::Rc;
    println!("Rc 不是 Send: {}", !std::marker::Send);
}

// ============================================================================
// 7. Union
// ============================================================================

fn union_examples() {
    println!("\n================== Union ==================");

    #[repr(C)]
    union Data {
        as_bytes: [u8; 4],
        as_i32: i32,
    }

    let mut data = Data { as_i32: 0x41424344 };  // 'ABCD' 的 ASCII

    unsafe {
        println!("as_i32: {:#x}", data.as_i32);
        println!("as_bytes: {:?}", data.as_bytes);

        // 修改一个字段会影响另一个
        data.as_bytes[0] = 0x61;  // 'a'
        println!("修改后 as_i32: {:#x}", data.as_i32);
    }

    // ============================================================================
    // 2. 模拟枚举
    // ============================================================================

    #[repr(C)]
    union Variant {
        as_int: i32,
        as_float: f32,
    }

    #[repr(C)]
    struct TaggedUnion {
        tag: u8,
        data: Variant,
    }

    const TAG_INT: u8 = 0;
    const TAG_FLOAT: u8 = 1;

    fn process_union(value: TaggedUnion) {
        unsafe {
            match value.tag {
                TAG_INT => println!("整数: {}", value.data.as_int),
                TAG_FLOAT => println!("浮点数: {}", value.data.as_float),
                _ => println!("未知标签"),
            }
        }
    }

    let int_union = TaggedUnion {
        tag: TAG_INT,
        data: Variant { as_int: 42 },
    };

    let float_union = TaggedUnion {
        tag: TAG_FLOAT,
        data: Variant { as_float: 3.14 },
    };

    process_union(int_union);
    process_union(float_union);
}

// ============================================================================
// 8. 编写安全抽象
// ============================================================================

fn safe_abstractions() {
    println!("\n================== 安全抽象 ==================");

    // 安全的 API 包装 unsafe 代码
    struct SafeVec {
        data: Vec<i32>,
    }

    impl SafeVec {
        pub fn new() -> Self {
            SafeVec { data: Vec::new() }
        }

        pub fn push(&mut self, value: i32) {
            self.data.push(value);
        }

        pub fn get(&self, index: usize) -> Option<&i32> {
            self.data.get(index)
        }

        // 内部 unsafe 操作，但对外暴露安全接口
        pub fn get_unchecked(&self, index: usize) -> &i32 {
            unsafe {
                self.data.get_unchecked(index)
            }
        }

        pub fn len(&self) -> usize {
            self.data.len()
        }
    }

    let mut vec = SafeVec::new();
    vec.push(1);
    vec.push(2);
    vec.push(3);

    println!("SafeVec: {:?}", vec.get(0));
    println!("SafeVec len: {}", vec.len());

    unsafe {
        println!("get_unchecked(1): {}", vec.get_unchecked(1));
    }

    // ============================================================================
    // 2. 借用检查器的不变量
    // ============================================================================

    struct RawVec<T> {
        ptr: *mut T,
        len: usize,
        cap: usize,
    }

    impl<T> RawVec<T> {
        fn new() -> Self {
            RawVec {
                ptr: std::ptr::null_mut(),
                len: 0,
                cap: 0,
            }
        }

        fn push(&mut self, value: T) {
            if self.cap == 0 {
                // 分配内存
                let layout = std::alloc::Layout::array::<T>(4).unwrap();
                let ptr = unsafe { std::alloc::alloc(layout) as *mut T };
                self.ptr = ptr;
                self.cap = 4;
            }

            // 写入值
            unsafe {
                std::ptr::write(self.ptr.add(self.len), value);
            }
            self.len += 1;
        }

        fn get(&self, index: usize) -> Option<&T> {
            if index < self.len {
                unsafe {
                    Some(&*self.ptr.add(index))
                }
            } else {
                None
            }
        }
    }

    let mut raw_vec = RawVec::<i32>::new();
    raw_vec.push(1);
    raw_vec.push(2);
    println!("RawVec get(0): {:?}", raw_vec.get(0));
}

// ============================================================================
// 9. 何时使用 unsafe
// ============================================================================

fn when_to_use_unsafe() {
    println!("\n================== 何时使用 unsafe ==================");

    println!("使用 unsafe 的合理场景:");
    println!("1. 与 C 库交互 (FFI)");
    println!("2. 底层系统编程");
    println!("3. 性能关键代码");
    println!("4. 实现其他语言无法提供的安全抽象");
    println!();

    println!("使用 unsafe 的原则:");
    println!("- 最小化 unsafe 代码范围");
    println!("- 将 unsafe 封装在安全抽象后面");
    println!("- 文档化不变性");
    println!("- 进行额外测试");
    println!("- 使用 #[deny(unsafe_code)] 限制 unsafe 范围");
}

// ============================================================================
// 主函数
// ============================================================================

fn main() {
    five_powers();
    raw_pointers();
    ffi_examples();
    manual_memory();
    static_variables();
    unsafe_trait_examples();
    union_examples();
    safe_abstractions();
    when_to_use_unsafe();

    println!("\n================== Unsafe Rust 总结 ==================");
    println!();
    println!("【Unsafe 五项超能力】");
    println!("1. 解引用原始指针");
    println!("2. 调用 unsafe 函数");
    println!("3. 访问可变静态变量");
    println!("4. 实现 unsafe trait");
    println!("5. 访问 union");
    println!();
    println!("【注意事项】");
    println!("- unsafe 不等于危险，只是不受信任");
    println!("- 最小化 unsafe 代码范围");
    println!("- 封装在安全抽象后面");
    println!("- 文档化不变性");
    println!();
    println!("【常见用途】");
    println!("- FFI 外部函数接口");
    println!("- 与操作系统交互");
    println!("- 高性能库实现");
    println!("- 手动内存管理");
}

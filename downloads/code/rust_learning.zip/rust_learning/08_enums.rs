// =============================================================================
// Rust 学习示例 8: 枚举 (Enums)
// =============================================================================
// 枚举允许你定义一个类型，该类型可以有固定的几种可能的值
// 本文件将详细介绍 Rust 中枚举的定义、使用和方法

// ============================================================================
// 1. 基础枚举
// ============================================================================

// 定义一个简单的枚举
enum Direction {
    Up,       // 上
    Down,     // 下
    Left,     // 左
    Right,    // 右
}

fn basic_enum_examples() {
    println!("================== 基础枚举 ==================");

    // 创建枚举值
    let direction = Direction::Up;

    // match 枚举
    match direction {
        Direction::Up => println!("向上"),
        Direction::Down => println!("向下"),
        Direction::Left => println!("向左"),
        Direction::Right => println!("向右"),
    }

    // 枚举值的相等性
    let d1 = Direction::Up;
    let d2 = Direction::Up;
    println!("d1 == d2: {}", d1 == d2);
}

// ============================================================================
// 2. 枚举与数据
// ============================================================================
// 枚举的每个变体都可以携带数据

enum Message {
    Quit,                         // 无数据
    Move { x: i32, y: i32 },     // 命名字段，类似结构体
    Write(String),                // 元组结构体
    ChangeColor(u8, u8, u8),      // RGB 颜色
}

fn enum_with_data() {
    println!("\n================== 带数据的枚举 ==================");

    let quit = Message::Quit;
    let move_msg = Message::Move { x: 10, y: 20 };
    let write_msg = Message::Write(String::from("Hello"));
    let color_msg = Message::ChangeColor(255, 128, 0);

    // match 处理不同变体
    fn process_message(msg: &Message) {
        match msg {
            Message::Quit => println!("退出程序"),
            Message::Move { x, y } => println!("移动到 ({}, {})", x, y),
            Message::Write(text) => println!("写入: {}", text),
            Message::ChangeColor(r, g, b) => {
                println!("改变颜色: RGB({}, {}, {})", r, g, b)
            }
        }
    }

    process_message(&move_msg);
    process_message(&write_msg);
    process_message(&color_msg);
}

// ============================================================================
// 3. Option 枚举
// ============================================================================
// Option 是 Rust 标准库中定义的一个枚举
// 用于表示一个值可能存在或不存在
// 这是 Rust 处理"空值"的方式，避免了其他语言中的 null 问题

fn option_enum_examples() {
    println!("\n================== Option 枚举 ==================");

    // Option 的定义（简化版）
    // enum Option<T> {
    //     None,           // 表示没有值
    //     Some(T),        // 表示有值
    // }

    // Some: 有值
    let some_number: Option<i32> = Some(5);
    let some_string: Option<&str> = Some("a string");

    // None: 无值
    let absent_number: Option<i32> = None;

    println!("some_number: {:?}", some_number);
    println!("some_string: {:?}", some_string);
    println!("absent_number: {:?}", absent_number);

    // ============================================================================
    // 4. Option 的使用
    // ============================================================================

    fn plus_one(x: Option<i32>) -> i32 {
        match x {
            None => 0,        // 如果没有值，返回 0
            Some(i) => i + 1, // 如果有值，加 1
        }
    }

    let five = Some(5);
    let none: Option<i32> = None;

    println!("plus_one(five) = {}", plus_one(five));
    println!("plus_one(none) = {}", plus_one(none));

    // ============================================================================
    // 5. Option 的常用方法
    // ============================================================================

    let some_value: Option<i32> = Some(10);

    // is_some() 和 is_none()
    println!("is_some: {}", some_value.is_some());
    println!("is_none: {}", some_value.is_none());

    // unwrap() - 获取内部值，None 时 panic
    // let value = some_value.unwrap();  // 谨慎使用

    // unwrap_or() - 获取值或默认值
    let value = some_value.unwrap_or(0);
    println!("unwrap_or: {}", value);

    let none_value: Option<i32> = None;
    let default = none_value.unwrap_or(42);
    println!("None unwrap_or: {}", default);

    // unwrap_or_else() - 获取值或计算默认值
    let computed = none_value.unwrap_or_else(|| {
        println!("计算默认值...");
        100
    });
    println!("unwrap_or_else: {}", computed);

    // map() - 转换内部值
    let result = some_value.map(|x| x * 2);
    println!("map(x * 2): {:?}", result);

    // and_then() - 链式操作
    let result = some_value.and_then(|x| Some(x + 1));
    println!("and_then(x + 1): {:?}", result);

    // filter() - 过滤
    let result = some_value.filter(|x| *x > 5);
    println!("filter(x > 5): {:?}", result);

    // or() 和 or_else()
    let result = none_value.or(Some(100));
    println!("or(Some(100)): {:?}", result);

    let result = none_value.or_else(|| Some(200));
    println!("or_else: {:?}", result);

    // if let 语法
    if let Some(value) = some_value {
        println!("有值: {}", value);
    } else {
        println!("没有值");
    }
}

// ============================================================================
// 6. Result 枚举
// ============================================================================
// Result 用于错误处理
// enum Result<T, E> {
//     Ok(T),    // 成功，包含值
//     Err(E),   // 失败，包含错误
// }

fn result_enum_examples() {
    println!("\n================== Result 枚举 ==================");

    // 成功结果
    let ok_value: Result<i32, &str> = Ok(42);
    // 错误结果
    let err_value: Result<i32, &str> = Err("出错了");

    println!("Ok: {:?}", ok_value);
    println!("Err: {:?}", err_value);

    // match 处理
    match ok_value {
        Ok(v) => println!("成功: {}", v),
        Err(e) => println!("失败: {}", e),
    }

    match err_value {
        Ok(v) => println!("成功: {}", v),
        Err(e) => println!("失败: {}", e),
    }

    // ============================================================================
    // 7. Result 的常用方法
    // ============================================================================

    let ok: Result<i32, &str> = Ok(10);
    let err: Result<i32, &str> = Err("error");

    // is_ok() 和 is_err()
    println!("is_ok: {}", ok.is_ok());
    println!("is_err: {}", err.is_err());

    // unwrap() 和 unwrap_err()
    // let value = ok.unwrap();  // Ok 时返回内部值
    // let value = err.unwrap_err();  // Err 时返回内部值

    // unwrap_or() 和 unwrap_or_else()
    println!("unwrap_or: {}", ok.unwrap_or(0));
    println!("err unwrap_or: {}", err.unwrap_or(0));

    // map() - 转换 Ok 值
    let result = ok.map(|x| x * 2);
    println!("map(x * 2): {:?}", result);

    // map_err() - 转换 Err 值
    let result = err.map_err(|e| format!("Error: {}", e));
    println!("map_err: {:?}", result);

    // and_then() - 链式操作
    fn parse_positive(n: i32) -> Result<i32, &'static str> {
        if n > 0 {
            Ok(n)
        } else {
            Err("Not positive")
        }
    }

    let result = Ok(10).and_then(parse_positive);
    println!("and_then: {:?}", result);

    let result = Ok(-5).and_then(parse_positive);
    println!("and_then (error): {:?}", result);

    // ? 操作符
    // ? 操作符用于自动传播错误
    fn multiply_if_positive(a: i32, b: i32) -> Result<i32, &'static str> {
        if a < 0 || b < 0 {
            return Err("Negative number");
        }
        Ok(a * b)
    }

    fn add_and_multiply(a: i32, b: i32) -> Result<i32, &'static str> {
        let sum = a + b;
        multiply_if_positive(sum, sum)
    }

    println!("? 操作符: {:?}", add_and_multiply(2, 3));
}

// ============================================================================
// 8. 枚举的方法
// ============================================================================

#[derive(Debug)]
enum TrafficLight {
    Red,
    Yellow,
    Green,
}

impl TrafficLight {
    fn duration(&self) -> u32 {
        match self {
            TrafficLight::Red => 60,
            TrafficLight::Yellow => 5,
            TrafficLight::Green => 45,
        }
    }

    fn next(&self) -> TrafficLight {
        match self {
            TrafficLight::Red => TrafficLight::Green,
            TrafficLight::Yellow => TrafficLight::Red,
            TrafficLight::Green => TrafficLight::Red,
        }
    }
}

fn enum_methods() {
    println!("\n================== 枚举方法 ==================");

    let light = TrafficLight::Red;
    println!("当前信号: {:?}", light);
    println!("持续时间: {} 秒", light.duration());

    let next_light = light.next();
    println!("下一个信号: {:?}", next_light);
}

// ============================================================================
// 9. 枚举与 trait
// ============================================================================

trait Describe {
    fn describe(&self) -> String;
}

#[derive(Debug)]
enum Shape {
    Circle(f64),           // 半径
    Rectangle(f64, f64),  // 宽和高
    Triangle(f64, f64, f64),  // 三边
}

impl Describe for Shape {
    fn describe(&self) -> String {
        match self {
            Shape::Circle(r) => format!("圆形 (半径={})", r),
            Shape::Rectangle(w, h) => format!("矩形 ({}x{})", w, h),
            Shape::Triangle(a, b, c) => format!("三角形 (边={},{},{})", a, b, c),
        }
    }
}

fn enum_with_trait() {
    println!("\n================== 枚举与 trait ==================");

    let shapes = vec![
        Shape::Circle(5.0),
        Shape::Rectangle(4.0, 6.0),
        Shape::Triangle(3.0, 4.0, 5.0),
    ];

    for shape in &shapes {
        println!("{}", shape.describe());
    }
}

// ============================================================================
// 10. 枚举与模式匹配
// ============================================================================

fn enum_pattern_matching() {
    println!("\n================== 枚举与模式匹配 ==================");

    #[derive(Debug)]
    enum Tree {
        Leaf(i32),
        Branch {
            value: i32,
            left: Box<Tree>,
            right: Box<Tree>,
        },
    }

    // 创建一棵二叉树
    let tree = Tree::Branch {
        value: 1,
        left: Box::new(Tree::Branch {
            value: 2,
            left: Box::new(Tree::Leaf(4)),
            right: Box::new(Tree::Leaf(5)),
        }),
        right: Box::new(Tree::Leaf(3)),
    };

    // 递归函数处理树
    fn sum_tree(tree: &Tree) -> i32 {
        match tree {
            Tree::Leaf(n) => *n,
            Tree::Branch { value, left, right } => {
                value + sum_tree(left) + sum_tree(right)
            }
        }
    }

    fn find_max(tree: &Tree) -> i32 {
        match tree {
            Tree::Leaf(n) => *n,
            Tree::Branch { value, left, right } => {
                *value.max(&find_max(left)).max(&find_max(right))
            }
        }
    }

    println!("树的总和: {}", sum_tree(&tree));
    println!("树的最大值: {}", find_max(&tree));

    // 使用 match 的高级技巧
    // 使用 @ 绑定变量
    fn print_if_large(tree: &Tree) {
        match tree {
            Tree::Leaf(n) if *n > 10 => println!("大叶子: {}", n),
            Tree::Leaf(n) => println!("小叶子: {}", n),
            Tree::Branch { value, .. } if *value > 10 => {
                println!("大分支: {}", value)
            }
            Tree::Branch { value, .. } => println!("小分支: {}", value),
        }
    }

    print_if_large(&tree);

    // 匹配多个枚举变体
    enum Status {
        Active,
        Inactive,
        Suspended,
    }

    let status = Status::Active;

    match status {
        Status::Active | Status::Suspended => {
            println!("用户处于活动状态")
        }
        Status::Inactive => println!("用户未激活"),
    }
}

// ============================================================================
// 11. 枚举的实现细节
// ============================================================================

fn enum_implementation() {
    println!("\n================== 枚举实现细节 ==================");

    // 枚举的内存占用
    println!("Option<i32> 大小: {} bytes", std::mem::size_of::<Option<i32>>());
    println!("i32 大小: {} bytes", std::mem::size_of::<i32>());

    // Result 的大小
    println!("Result<i32, &str> 大小: {} bytes", std::mem::size_of::<Result<i32, &str>>());

    // 枚举可以转换为整数（需要显式转换）
    enum Color {
        Red = 0xFF0000,
        Green = 0x00FF00,
        Blue = 0x0000FF,
    }

    impl Color {
        fn to_hex(&self) -> u32 {
            *self as u32
        }
    }

    println!("Color::Red as u32: 0x{:06X}", Color::Red as u32);
    println!("Color::Green as u32: 0x{:06X}", Color::Green as u32);
    println!("Color::Blue as u32: 0x{:06X}", Color::Blue as u32);

    // 从整数转换
    fn color_from_hex(hex: u32) -> Option<Color> {
        match hex {
            0xFF0000 => Some(Color::Red),
            0x00FF00 => Some(Color::Green),
            0x0000FF => Some(Color::Blue),
            _ => None,
        }
    }

    if let Some(color) = color_from_hex(0xFF0000) {
        println!("找到颜色: 0x{:06X}", color.to_hex());
    }
}

// ============================================================================
// 12. 常用标准库枚举
// ============================================================================

fn standard_library_enums() {
    println!("\n================== 标准库常用枚举 ==================");

    // Option<T>
    let value: Option<i32> = Some(42);
    if let Some(v) = value {
        println!("Option value: {}", v);
    }

    // Result<T, E>
    let result: Result<i32, &str> = Ok(42);
    if let Ok(v) = result {
        println!("Result value: {}", v);
    }

    // std::io::ErrorKind
    use std::io::ErrorKind;
    let error_kind = ErrorKind::NotFound;
    match error_kind {
        ErrorKind::NotFound => println!("文件未找到"),
        ErrorKind::PermissionDenied => println!("权限被拒绝"),
        _ => println!("其他 IO 错误"),
    }

    // std::cmp::Ordering
    use std::cmp::Ordering;
    let ordering = Ordering::Less;
    match ordering {
        Ordering::Less => println!("小于"),
        Ordering::Equal => println!("等于"),
        Ordering::Greater => println!("大于"),
    }

    // std::fmt::Result
    use std::fmt;
    fn write_greeting(writer: &mut dyn fmt::Write) -> fmt::Result {
        writer.write_str("Hello, world!")
    }
}

// ============================================================================
// 主函数
// ============================================================================

fn main() {
    basic_enum_examples();
    enum_with_data();
    option_enum_examples();
    result_enum_examples();
    enum_methods();
    enum_with_trait();
    enum_pattern_matching();
    enum_implementation();
    standard_library_enums();

    println!("\n================== 枚举总结 ==================");
    println!();
    println!("【枚举基础】");
    println!("- enum 关键字定义枚举");
    println!("- 每个变体可以是不同的数据类型");
    println!();
    println!("【Option<T>】");
    println!("- Option<T> 表示值可能存在或不存在");
    println!("- Some(T) 有值，None 无值");
    println!("- 避免 null 引用的安全问题");
    println!();
    println!("【Result<T, E>】");
    println!("- Result<T, E> 表示操作可能成功或失败");
    println!("- Ok(T) 成功，Err(E) 失败");
    println!("- ? 操作符自动传播错误");
    println!();
    println!("【常用方法】");
    println!("- is_some(), is_ok() - 检查状态");
    println!("- unwrap(), unwrap_or() - 获取值");
    println!("- map(), and_then() - 转换");
    println!("- if let, match - 模式匹配");
}
